package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class CustomerHistoryObject {
	  
	//static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	public static WebElement getDraftCAURL(WebDriver driver)
	   {
		
		By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[2]/td[4]/a[text()='Draft']");
		
		try { 
			
			
			driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			
			
			/**WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[2]/td[4]/a[text()='Draft']"));
			return element;*/
			
			
				
				return driver.findElement(locator);
			} catch (NoSuchFrameException e) {
				System.out.println("Exception Occurred Suring Frame Switch Rertying");
				
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					driver.switchTo().defaultContent();
					driver.switchTo().frame("advisorDesktop");
					driver.switchTo().frame("cframe_ms__id46");
					
						return driver.findElement(locator);
					}catch (NoSuchFrameException e1){
						System.out.println("Could Not Find Frame on Page . . . ");
						e1.printStackTrace();
						return null;
					}catch (NoSuchElementException e1) {
						System.out.println("Exception Occured for Element Researching again");
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);	
					}catch (Exception e1) {
						e.printStackTrace();
						return null;
					}
				
			}catch (NoSuchElementException e) {
				System.out.println("Exception Occurred Researching Element on Page Again . . ");
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	  
	  public static WebElement getSanctionedCAURL(WebDriver driver)
	   {
	  
		By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[2]/td[4]/a[text()='Sanction']");
		
	try { 
			
			
			driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			
			
				
				return driver.findElement(locator);
			} catch (NoSuchFrameException e) {
				System.out.println("Exception Occurred during Frame Switch Rertying");
				try {
					Thread.sleep(7000);
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
					try {
					driver.switchTo().defaultContent();
					driver.switchTo().frame("advisorDesktop");
					driver.switchTo().frame("cframe_ms__id46");
						return driver.findElement(locator);
					}catch (NoSuchFrameException e1){
						System.out.println("Could Not Find Frame on Page . . .");
						e1.printStackTrace();
						return null;
					}
					catch (NoSuchElementException e1) {
						System.out.println("Exception Occured for Element Researching again");
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);	
					}catch (Exception e1) {
						e.printStackTrace();
						return null;
					}
				
			}catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}

	   }
	  
	 
}
