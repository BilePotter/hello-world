package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class GradingSummaryAndHistoryObject {
	
	//public static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	public static WebElement getRatingAgencyCheckBox(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#Radio3"));
		
		
		
		  By locator = By.cssSelector("input#Radio3");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		
		
	}

	public static WebElement getUngradedCheckBox(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#Radio0"));
		
		 By locator = By.cssSelector("input#Radio0");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getRatingAgencyDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#firstChoice"));
		
		 By locator = By.cssSelector("select#firstChoice");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getRatingAgencyGoButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#Go"));
		
		 By locator = By.cssSelector("input#Go");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getRatingAgencyPITDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#secondChoice"));
		
		 By locator = By.cssSelector("select#secondChoice");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getGradeEquivalentPITDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#GEpit"));
		
		 By locator = By.cssSelector("select#GEpit");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getGradeEquivalentTTCDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#GEttc"));
		
		 By locator = By.cssSelector("select#GEttc");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getSaveGradesButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#savebutton"));
		
		 By locator = By.cssSelector("input#savebutton");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

}
