package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class PageHeaderObject {
	
	   //static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	   public static WebElement getCustomerSearchURL(WebDriver driver)
	   {	
		   
		  // driver.switchTo().defaultContent();
		   //driver.switchTo().frame("advisorDesktop");
//	      WebElement element = driver.findElement(By.xpath("/html/body/menu/div/span[2]/span[2][text()='Customer Search']"));
//	      return element;
	      
	  	/*By locator = By.xpath("/html/body/menu/div/span[2]/span[2][text()='Customer Search']");
		try {
			
			return driver.findElement(locator);
		} catch (NoSuchElementException e) {
			return TestBase.explicitWaitHelper(driver, locator , waitTimer);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		} */
	    
		
		
		
		   By locator = By.xpath("/html/body/menu/div/span[2]/span[2][text()='Customer Search']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
							System.out.println("Frame Not Found Exception Occured Researching Again . . .");
							try {
								Thread.sleep(8000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
						
							try {
								driver.switchTo().defaultContent();
								driver.switchTo().frame("advisorDesktop");
								return driver.findElement(locator);
								} catch (NoSuchFrameException e2){
									System.out.println("Could Not Find Frame...");
									e2.printStackTrace();
									return null;
								}
							 	catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}

	      
	   }
	   public static WebElement getLogoutURL(WebDriver driver)
	   {	
		   
		   /*driver.switchTo().defaultContent();
		   driver.switchTo().frame("advisorDesktop");
	      WebElement element = driver.findElement(By.xpath("/html/body/menu/div/span[8]/span[2]/span[@class='logoutMenuItem']"));
	      return element; */
	      
	      
	      
	      By locator = By.xpath("/html/body/menu/div/span[8]/span[2]/span[@class='logoutMenuItem']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
							System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
							try {
								Thread.sleep(6000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
							try {
								driver.switchTo().defaultContent();
								driver.switchTo().frame("advisorDesktop");
							
								return driver.findElement(locator);
								}catch (NoSuchFrameException e2){
									System.out.println("Could Not Find Frame...");
									e2.printStackTrace();
									return null;
								}catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
		
	      
	      
	   } //method ends here
	   
	      
}
