package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class SanctionTabObject {
	
	 //public static int waitTimer = 5;
	 
	 public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	  
	  public static WebElement getSanctionerCommentsTextBox(WebDriver driver)
	   {
		   
		   switchToSanctionFrame(driver);
		  //WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/textarea[@id='currentComments']"));
	      //return element;
	      
	      

		  By locator = By.xpath("/html/body/form/table/tbody/tr[14]/td/textarea[@id='currentComments']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	      
	   }
	  
	  public static WebElement getHunterRequiredDropDow(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	  
	  public static WebElement getConditionOfSanctionTextBox(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	  
	  public static WebElement getSanctionDecisionDropDown(WebDriver driver)
	   {
		  
		   
	      //WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[27]/td/select[@id='statuscode']"));
	      //return element;
	      
	      

		  By locator = By.xpath("/html/body/form/table/tbody/tr[27]/td/select[@id='statuscode']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }

	public static WebElement getSaveButton(WebDriver driver) {
		
		/*driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
	driver.switchTo().frame("cframe_ms__id61");
	   driver.switchTo().frame("Sanction");*/
		
		
		//WebElement element = driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td[2]/input[@id='sanctionSaveButton']"));
	     // return element;
	      

		  By locator = By.xpath("/html/body/form/table[2]/tbody/tr/td[2]/input[@id='sanctionSaveButton']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	
	private static void switchToSanctionFrame(WebDriver driver){
		//driver.switchTo().frame("Sanction");
		
		
		  try {
			  driver.switchTo().frame("Sanction");
		  }catch(NoSuchFrameException e){
			  System.out.println("Frame not frame not found on page trying to find it Again . . .");
			  	try {
			  		Thread.sleep(4000);
			  	} catch (InterruptedException e1) {
			  		// TODO Auto-generated catch block
			  		e1.printStackTrace();
			  	}
			  	
			  	try {
			  		driver.switchTo().frame("Sanction");
			  	
			  	}catch(NoSuchFrameException e1)
			  	{
			  		System.out.println("Could Not Find Frame");
			  		e1.printStackTrace();
			  	}
			  	catch (Exception e1){
			  		e1.printStackTrace();
			  	}
		  }
		
		
	}
	  
	   

}
