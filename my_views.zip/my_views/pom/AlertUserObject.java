package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class AlertUserObject {
	
	//static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	
	public static WebElement getSupportUserDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		By locator = By.cssSelector("select#RMSUser");
		  try 
		  {driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			return driver.findElement(locator);
			} catch(NoSuchFrameException e1){
				System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
				driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id46");
				
					return driver.findElement(locator);
				} catch (NoSuchFrameException e2){
					System.out.println("Could Not Find Frame on this page");
					e2.printStackTrace();
					return null;
				}
					catch (NoSuchElementException e2) {
					// TODO Auto-generated catch block
					System.out.println("Exception Occurred Researching Element Again . . ");
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				
			}
		  
		  catch (NoSuchElementException e) {
				
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCreditTeamDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#projag2"));
		
		
		
		 
	      By locator = By.cssSelector("select#projag2");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getRCUTeamDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#rcuteam"));
		
		 By locator = By.cssSelector("select#rcuteam");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	
	public static WebElement getRCUOwnerDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#rcuOwner"));
		
		 By locator = By.cssSelector("select#rcuOwner");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	
	public static WebElement getLA1OwnerDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#LA1Owner"));
		
		 By locator = By.cssSelector("select#LA1Owner");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	
	public static WebElement getLA2OwnerDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#LA2Owner"));
		
		 By locator = By.cssSelector("select#LA2Owner");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getRCUTeamButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//input[@type='image' and @alt='Go1']"));
		
		 By locator = By.xpath("//input[@type='image' and @alt='Go1']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getSaveButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//input[@type='image' and @alt='Save']"));
		
		 By locator = By.xpath("//input[@type='image' and @alt='Save']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

}
