package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class CustomerSearchResultsObject {
	
	
	  //static int waitTimer = 5;
	  
	  public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	   public static WebElement getCustomerNameURL(WebDriver driver)
	   {	
		 
//	     WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/a"));
//	      return element;
	      By locator = By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/a");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	      
	   }
		
	   
}
