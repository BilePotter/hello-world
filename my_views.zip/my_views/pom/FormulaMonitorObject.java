package com.ibm.barclays.zeus.pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class FormulaMonitorObject {

	//public static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	public static WebElement getFMAddButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#btnAddFormula"));
		
		
		
	      By locator = By.cssSelector("input#btnAddFormula");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		
	}
	
	public static WebElement getDebentureChargeIDTextBox(WebDriver driver) {
		// TODO Auto-generated method stub

	      By locator = By.cssSelector("input#debentureChargeId");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		
	}

	public static WebElement getMonitorTypeDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#monitorType"));
		
	      By locator = By.cssSelector("select#monitorType");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCalculationTypeDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#calculationType"));
		
	      By locator = By.cssSelector("select#calculationType");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCalculationTypeButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#formulaMonitorGo"));
		
	      By locator = By.cssSelector("input#formulaMonitorGo");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCalculationTypeFormula(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#formula"));
		
	      By locator = By.cssSelector("select#formula");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCalculationTypeFormulaGoButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input[type=image][alt=Change Standard Formula]"));
		
		
	      By locator = By.cssSelector("input[type=image][alt=Change Standard Formula]");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getCalculationTypeFormulaApplyButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input[type=image][alt=Apply]"));
		
		
	      By locator = By.cssSelector("input[type=image][alt=Apply]");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getLinkFacilitiesURL(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//a[text()='Click Here to Link Facilities & Monitor Information']"));
		
		
		
	      By locator = By.xpath("//a[text()='Click Here to Link Facilities & Monitor Information']");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static List<WebElement> getFcailitiesCheckBoxes(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElements(By.cssSelector("input#checkLinkFac"));
		
		
	      By locator = By.cssSelector("input#checkLinkFac");
			try {
				
				return driver.findElements(locator);
			} catch (NoSuchElementException e) {
				System.out.println("Exception Occurred Researching Elements again . . ");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return driver.findElements(locator);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getLinkFacilitiesGoButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#btnGo"));
		
		
	      By locator = By.cssSelector("input#btnGo");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getLinkMonitorInfoCheckBox(WebDriver driver, String monitorInfoID) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input[id=checkMonitorInfo]"));
		
		
		//////return driver.findElement(By.xpath("//td[contains(text(),'"+monitorInfoID+"')]/parent::*/child::td[1]/child::input"));
		//preceding-sibling::td[starts-with(@id,'monitor')]
		
		
		
		
	      By locator = By.xpath("//td[contains(text(),'"+monitorInfoID+"')]/parent::*/child::td[1]/child::input");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getLinkFacilitiesApplyButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#btnApply"));
		
		
		
	      By locator = By.cssSelector("input#btnApply");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFormulaMonitorDetailsFrequencyDropDown(
			WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#frequency"));
		
		
	      By locator = By.cssSelector("select#frequency");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFormulaMonitorDetailsFirstPeriodEndDate(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#periodEnd"));
		
		
	      By locator = By.cssSelector("input#periodEnd");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFormulaMonitorDetailsCalculationBasis(
			WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#calculationBasis"));
		
	      By locator = By.cssSelector("select#calculationBasis");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getTargetCoverDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#targetCover"));
		
		
		
	      By locator = By.cssSelector("select#targetCover");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFormulaMonitorDetailsCalculationBasisGoButton(
			WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#calculationBasisGo"));
		
		
		
	      By locator = By.cssSelector("input#calculationBasisGo");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getTargetCoverGoButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return 	driver.findElement(By.cssSelector("input#targetCoverGoButton"));
		
		
	      By locator = By.cssSelector("input#targetCoverGoButton");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getResultMustBeDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#resultMustBe"));
		
		
	      By locator = By.cssSelector("select#resultMustBe");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getTimesCover(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#timesCover1"));
		
		
		
	      By locator = By.cssSelector("input#timesCover1");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFormulaMonitorSaveButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#saveBtn"));
		
		
	      By locator = By.cssSelector("input#saveBtn");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}
	public static WebElement getFMSavedID(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//form[@id='FormulaMonitorSummary']/table[1]/tbody[1]/tr[2]/td[2]"));
		
		
	      By locator = By.xpath("//form[@id='FormulaMonitorSummary']/table[1]/tbody[1]/tr[2]/td[2]");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}

	public static WebElement getFMFrequencySaved(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//form[@id='FormulaMonitorSummary']/table[1]/tbody[1]/tr[2]/td[7]"));
		
		
		
	      By locator = By.xpath("//form[@id='FormulaMonitorSummary']/table[1]/tbody[1]/tr[2]/td[7]");
			try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
	}
	
	

}
