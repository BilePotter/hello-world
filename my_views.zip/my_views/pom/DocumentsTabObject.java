package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class DocumentsTabObject {
	
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	   public static WebElement getGroupCommentaryBrowseTextBox(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   
	   public static WebElement getSelectCustomerBrowseTextBox(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getAttachCommentaryButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getDeleteCommentaryButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getSelectCustomerRadio(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   
	  
	   public static WebElement getAttachDocumentButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getDeleteDocumentButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   

}
