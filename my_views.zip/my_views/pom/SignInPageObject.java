package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class SignInPageObject {
	

//static int waitTimer = 5;

public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));

	   public static WebElement getUserNameText(WebDriver driver)
	   
	   
	   {
		  
	    // WebElement element = driver.findElement(By.xpath("//input[@id='loginUserName']"));
	      //return element;
	      
	      By locator = By.xpath("//input[@id='loginUserName']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
		
	   //Exit Button
	   public static WebElement getExitButton(WebDriver driver)
	   {
	     //WebElement element = driver.findElement(By.xpath("//img[@name='exit']"));
	      //return element;
	      
	      
	      By locator = By.xpath("//img[@name='exit']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	   }
	   
	   //Continue Button
	   public static WebElement getContinueButton(WebDriver driver)
	   {
	      //WebElement element = driver.findElement(By.xpath("//input[@name='continue']"));
	    //  return element;
	      
	      By locator = By.xpath("//input[@name='continue']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	   }
	   
	   public static WebElement getUserIDLoggedInText(WebDriver driver)
	   {
		  
		   By locator = By.xpath("/html/body/applicationbanner/table/tbody/tr/td[2]/span[@id='userName_applicationBanner']");
		   try {
		   driver.switchTo().defaultContent();
		  driver.switchTo().frame("advisorDesktop");
//	      WebElement element = driver.findElement(By.xpath("/html/body/applicationbanner/table/tbody/tr/td[2]/span[@id='userName_applicationBanner']"));
//	      return element;
	      
				return driver.findElement(locator);
			} catch (NoSuchFrameException e) {
				System.out.println("Exception Ouccured for advisorDesktop frame");
						
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						
								try {	
									driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
					  		
					  				return driver.findElement(locator);
					  
					  			}catch (NoSuchFrameException e2) {
									System.out.println("Could not find Frame . . .");
									e2.printStackTrace();
									return  null;
					  			}
								catch (NoSuchElementException e1) {
					  					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					  				}
			}
					  
			catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	      
	      
	      
	      
	      
	      
	   }
	   
	   
	   
	  
	   

}
