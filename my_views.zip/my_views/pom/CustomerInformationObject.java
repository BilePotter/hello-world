package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class CustomerInformationObject {

	//public static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	public static WebElement getDRUFlagDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#druFlag"));
		
		
		By locator = By.cssSelector("select#druFlag");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				
				System.out.println("Exception Occurred Researching Element on Page Again . . ");
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		
		
	}

	public static WebElement getCustomerInformationSaveButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input[tabIndex=14][type=image]"));
		
		
		By locator = By.cssSelector("input[tabIndex=14][type=image]");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				System.out.println("Exception Occurred Researching Element on Page Again . . ");
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		
	}


}
