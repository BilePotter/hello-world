package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class AmendGroupTabObject {
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	   public static WebElement getCustomerCheckbox(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getAddButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getRemoveButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSaveButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getLeadRadioButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 

}
