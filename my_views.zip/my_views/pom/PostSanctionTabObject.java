package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class PostSanctionTabObject {
	
	//public static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	  public static WebElement getApplicationOutcomeDropDown(WebDriver driver)
	   {
		/*driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
		driver.switchTo().frame("cframe_ms__id61");
		driver.switchTo().frame("postSanction");*/
		  
		  switchToPostSanctionFrame(driver);
		
		 // WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr/td[2]/select[@tabIndex='1']"));
		//return element;
		
		
		  By locator = By.xpath("/html/body/form/table/tbody/tr/td[2]/select[@tabIndex='1']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		
		
	   }
	  
	  public static WebElement getFurtherPostSanctionCommentsTextBox(WebDriver driver)
	   {
		  
			//WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea[@tabIndex='2']"));
			//return element;
			
			
			 By locator = By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea[@tabIndex='2']");
		      try {
					
					return driver.findElement(locator);
				} catch (NoSuchElementException e) {
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	   }
	  
	  public static WebElement getSaveButton(WebDriver driver)
	   {
		  
			//WebElement element = driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td[4]/input[@type='image']"));
			//return element;
			
			
			 By locator = By.xpath("/html/body/form/table[2]/tbody/tr/td[4]/input[@type='image']");
		      try {
					
					return driver.findElement(locator);
				} catch (NoSuchElementException e) {
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	   }
	  
	  public static WebElement getCancelButton(WebDriver driver)
	   {
		  
				//WebElement element = driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td[3]/input[@id='idCancel']"));
				//return element;
				
				
				 By locator = By.xpath("/html/body/form/table[2]/tbody/tr/td[3]/input[@id='idCancel']");
			      try {
						
						return driver.findElement(locator);
					} catch (NoSuchElementException e) {
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					}
					catch (Exception e) {
						e.printStackTrace();
						return null;
					}
	   }
	  
	  private static void switchToPostSanctionFrame(WebDriver driver){
		  
		  
		  try {
			  driver.switchTo().frame("postSanction");
		  }catch(NoSuchFrameException e){
			  System.out.println("Frame not frame not found on page trying to find it Again . . .");
			  	try {
			  		Thread.sleep(4000);
			  	} catch (InterruptedException e1) {
			  		// TODO Auto-generated catch block
			  		e1.printStackTrace();
			  	}
			  	
			  	try {
			  		driver.switchTo().frame("postSanction");
			  	
			  	}catch(NoSuchFrameException e1)
			  	{
			  		System.out.println("Could Not Find Frame");
			  		e1.printStackTrace();
			  	}
			  	catch (Exception e1){
			  		e1.printStackTrace();
			  	}
		  }
		  
		  
		  
	  }

}
