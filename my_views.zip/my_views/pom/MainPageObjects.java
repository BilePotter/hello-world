package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class MainPageObjects {
	
	//public static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	   public static WebElement getGroupSummaryTab(WebDriver driver)
	   {
		   
		   
	     WebElement element = driver.findElement(By.xpath(""));
	      return element;
	   }
		
	   //Customer System ID Text
	   public static WebElement getAmendGroupTab(WebDriver driver)
	   {
	     WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   
	   public static WebElement getCreateCATab(WebDriver driver)
	   {	
		 //go towards appropriate frame
		   /*driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id33");
	      WebElement element = driver.findElement(By.xpath("html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table//tbody/tr[1]/td[3]/span/span[2]/span[@title='Create Credit Application']"));
	      return element; */
	      
	      
	      
	      By locator = By.xpath("html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table//tbody/tr[1]/td[3]/span/span[2]/span[@title='Create Credit Application']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id33");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id33");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
		
		
		
	      
	      
	      
	   }
	   
	 
	   public static WebElement getCustomerReportsTab(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getDocumentsTab(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	  
	   
	   public static WebElement getGroupSummaryURL(WebDriver driver)
	   {
	      
		   /*driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id61");
		   WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[3]/td[2]/div[@id='task_t2']"));
	      return element; */
	      
	      
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[3]/td[2]/div[@id='task_t2']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id61");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id61");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
		
	      
	      
	      
	   }
	   
	   public static WebElement getCustomerInfoURL(WebDriver driver)
	   {
			/*driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			WebElement element = driver.findElement(By.xpath("//div[text()='Customer Information']"));
			return element; */
			
			
			 By locator = By.xpath("//div[text()='Customer Information']");
			   
			   try 
				  {
				   
				   driver.switchTo().defaultContent();
					driver.switchTo().frame("advisorDesktop");
					driver.switchTo().frame("cframe_ms__id46");
					return driver.findElement(locator);
					} catch(NoSuchFrameException e1){
							System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
							try {
								Thread.sleep(6000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
								try {
									 
									   driver.switchTo().defaultContent();
										driver.switchTo().frame("advisorDesktop");
										driver.switchTo().frame("cframe_ms__id46");
								} catch (Exception e3) {
									// TODO Auto-generated catch block
									System.out.println("Could Not Find Frame...");
									e3.printStackTrace();
								}
								try {
									return driver.findElement(locator);
									} catch (NoSuchElementException e2) {
										// TODO Auto-generated catch block
										System.out.println("Exception Occurred Researching Element Again . . ");
							
										return TestBase.explicitWaitHelper(driver, locator , waitTimer);
									}catch (Exception e) {
										e.printStackTrace();
										return null;
									}
						
					}
				  
				  catch (NoSuchElementException e) {
						
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					}
					catch (Exception e) {
						e.printStackTrace();
						return null;
					}
			
			
			
	   }
	   
	   public static WebElement getCustomerHistoryURL(WebDriver driver)
	   {
		   /*driver.switchTo().defaultContent();
		   driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
		   WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[5]/td[2]/div[@title='Customer History']"));
	      return element;  */
	      
	      
	 	 By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[5]/td[2]/div[@title='Customer History']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id46");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id46");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	      
	      
	      
	      
	   }
	   
	   public static WebElement getFacilitySummaryURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSecuritySummaryURL(WebDriver driver)
	   {
	      
		   /* driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[10]/td[2]/div[@title='Security Summary']"));
  			return element; */
  			
  			By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/div/table/tbody/tr[10]/td[2]/div[@title='Security Summary']");
 		   
 		   try 
 			  {
 			   
 			   driver.switchTo().defaultContent();
 				driver.switchTo().frame("advisorDesktop");
 				driver.switchTo().frame("cframe_ms__id46");
 				return driver.findElement(locator);
 				} catch(NoSuchFrameException e1){
 						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
 						try {
 							Thread.sleep(6000);
 						} catch (InterruptedException e) {
 							// TODO Auto-generated catch block
 							e.printStackTrace();
 						}
 					
 							try {
 								 
 								   driver.switchTo().defaultContent();
 									driver.switchTo().frame("advisorDesktop");
 									driver.switchTo().frame("cframe_ms__id46");
 							} catch (Exception e3) {
 								// TODO Auto-generated catch block
 								System.out.println("Could Not Find Frame...");
 								e3.printStackTrace();
 							}
 							try {
 								return driver.findElement(locator);
 								} catch (NoSuchElementException e2) {
 									// TODO Auto-generated catch block
 									System.out.println("Exception Occurred Researching Element Again . . ");
 						
 									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
 								}catch (Exception e) {
 									e.printStackTrace();
 									return null;
 								}
 					
 				}
 			  
 			  catch (NoSuchElementException e) {
 					
 					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
 				}
 				catch (Exception e) {
 					e.printStackTrace();
 					return null;
 				}
 	      	
  			
	   }
	   
	   public static WebElement getGroupFacilitySummaryURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getGradingSummHistURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getPropertySlottingURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSeverityURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getOverviewBalSheetURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	
	   
	   public static WebElement getProfitLossURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   
	   public static WebElement getCashflowURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getRatiosURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getProjectionsURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getAlertUserURL(WebDriver driver)
	   {
	      
		  /* driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id33");
		   WebElement element = driver.findElement(By.xpath("//div[text()='Alert User']"));
	      return element;
	      */
	      
	      By locator = By.xpath("//div[text()='Alert User']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id33");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id33");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	     
	   }

	   
	   public static WebElement getMonitorInfoURL(WebDriver driver)
	   {
	     
	  	/*driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
		driver.switchTo().frame("cframe_ms__id46");	
		return driver.findElement(By.xpath("//div[text()='Monitor Information']"));*/
		
		
			By locator = By.xpath("//div[text()='Monitor Information']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id46");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id46");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	      
	   }
	   
	   public static WebElement getFormulaMonitorURL(WebDriver driver)
	   {
		  /*driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
		driver.switchTo().frame("cframe_ms__id46");	
	      return driver.findElement(By.xpath("//div[text()='Formula Monitors']"));*/
	      
	      
	      By locator = By.xpath("//div[text()='Formula Monitors']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id46");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id46");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	      
	      
	      
	      
	      
	      
	   }
	   
	   public static WebElement getInputActualsURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getMNCSummaryURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getMNCHistoryURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getEWLURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getForbearanceURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getImpairmentURL(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }

	public static WebElement getSanctionTab(WebDriver driver) {
					/*try {driver.switchTo().defaultContent();
					driver.switchTo().frame("advisorDesktop");
					driver.switchTo().frame("cframe_ms__id61");
			      WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table/tbody/tr[1]/td[5]/span/span[2]/span[@title='Sanction']"));
			      return element;
					} catch (NoSuchFrameException e){
						driver.switchTo().defaultContent();
						driver.switchTo().frame("advisorDesktop");
						driver.switchTo().frame("cframe_ms__id174");
				      WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table/tbody/tr[1]/td[5]/span/span[2]/span[@title='Sanction']"));
				      return element;
					}
					
					*/
					
					
					 By locator = By.xpath("/html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table/tbody/tr[1]/td[5]/span/span[2]/span[@title='Sanction']");
						try {
							
							//Searching in 161
							driver.switchTo().defaultContent();
							driver.switchTo().frame("advisorDesktop");
							driver.switchTo().frame("cframe_ms__id61");
							return driver.findElement(locator);

						}catch (NoSuchFrameException e){
							//Exception Occurred Researching in 174
							
								try {
									Thread.sleep(5000);
									} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
									}
							
									try {
										
										driver.switchTo().defaultContent();
										driver.switchTo().frame("advisorDesktop");
										driver.switchTo().frame("cframe_ms__id174");
											try {
												return driver.findElement(locator);
												} catch (NoSuchElementException e2) {
												// TODO Auto-generated catch block
												System.out.println("Exception Occurred Researching Element Again . . ");
									
												return TestBase.explicitWaitHelper(driver, locator , waitTimer);
												}catch (Exception e2) {
												e2.printStackTrace();
												return null;
												}
								
									}catch (NoSuchFrameException e4){
											//Searching in 174
										
										System.out.println("Frame Not Found Exception Occured Researching Again . . .");
												try{
													driver.switchTo().defaultContent();
													driver.switchTo().frame("advisorDesktop");
													driver.switchTo().frame("cframe_ms__id61");
													
															try {
																return driver.findElement(locator);
															} catch (NoSuchElementException e2) {
																// TODO Auto-generated catch block
																System.out.println("Exception Occurred Researching Element Again . . ");
										
																return TestBase.explicitWaitHelper(driver, locator , waitTimer);
															}catch (Exception e2) {
																e2.printStackTrace();
																return null;
															}
													}catch (NoSuchFrameException e5){
														
														//Exception Occurred Researching in 174
														
															
																try {
																	Thread.sleep(2000);
																} catch (InterruptedException e6) {
																	// TODO Auto-generated catch block
																	e6.printStackTrace();
																}
																try {
																driver.switchTo().defaultContent();
																driver.switchTo().frame("advisorDesktop");
																driver.switchTo().frame("cframe_ms__id174");
																
																	return driver.findElement(locator);
																} catch (NoSuchFrameException e2){
																	System.out
																			.println("Could not find Sanction Tab Frame");
																	e2.printStackTrace();return null;
																}
																catch (NoSuchElementException e2) {
																	// TODO Auto-generated catch block
																	System.out.println("Exception Occurred Researching Element Again . . ");
										
																	return TestBase.explicitWaitHelper(driver, locator , waitTimer);
																}catch (Exception e7) {
																	e7.printStackTrace();
																	return null;
																}
													
														
													}
									}
						}	
					
					
					
					
					
					
					
					
					
	}
	
	public static WebElement getPostSanctionTab(WebDriver driver) {
		
		 By locator = By.xpath("/html/body/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[1]/td[2]/div/tabpane/table/tbody/tr[1]/td[1]/div/table/tbody/tr[1]/td[6]/span/span[2]/span[@title='Post Sanction']");
		try {
			
			//Searching in 61
			driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id61");
			return driver.findElement(locator);

		}catch (NoSuchFrameException e){
			//Exception Occurred Researching in 61
				
				try {
					Thread.sleep(5000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
			
					try {
						//Searching in 174
						driver.switchTo().defaultContent();
						driver.switchTo().frame("advisorDesktop");
						driver.switchTo().frame("cframe_ms__id174");
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
								// TODO Auto-generated catch block
								System.out.println("Exception Occurred Researching Element Again . . ");
					
								return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e2) {
								e2.printStackTrace();
								return null;
								}
				
					}catch (NoSuchFrameException e4){
						System.out.println("Frame Not Found Exception Occured Researching Again . . .");
							//Searching in 61 again
						
									try {
										Thread.sleep(5000);
									} catch (InterruptedException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
						
						
								try{
									driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id61");
											try {
												return driver.findElement(locator);
											} catch (NoSuchElementException e2) {
												// TODO Auto-generated catch block
												System.out.println("Exception Occurred Researching Element Again . . ");
						
												return TestBase.explicitWaitHelper(driver, locator , waitTimer);
											}catch (Exception e2) {
												e2.printStackTrace();
												return null;
											}
									}catch (NoSuchFrameException e5){
										
										//Exception Occurred Researching in 174
										
											
												try {
													Thread.sleep(3000);
												} catch (InterruptedException e6) {
													// TODO Auto-generated catch block
													e6.printStackTrace();
												}
												try {
												driver.switchTo().defaultContent();
												driver.switchTo().frame("advisorDesktop");
												driver.switchTo().frame("cframe_ms__id174");
												
													return driver.findElement(locator);
												} catch (NoSuchFrameException e2){
													
													System.out.println("Could Not Find Post Sanction Tab Frame");
													e2.printStackTrace();
													return null;
												}catch (NoSuchElementException e2) {
													// TODO Auto-generated catch block
													System.out.println("Exception Occurred Researching Element Again . . ");
						
													return TestBase.explicitWaitHelper(driver, locator , waitTimer);
												}catch (Exception e7) {
													e7.printStackTrace();
													return null;
												}
									
										
									}
					}
		}
}

	public static WebElement getGradingHistoryAndSummaryURL(WebDriver driver) {
		// TODO Auto-generated method stub
		
		/*driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
		driver.switchTo().frame("cframe_ms__id46");	
		
		return driver.findElement(By.xpath("//div[text()='Grading Summary & History']"));*/
		
		
		
		
		
	    
	      
	      By locator = By.xpath("//div[text()='Grading Summary & History']");
		   
		   try 
			  {
			   
			   driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id46");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
						System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
						try {
							Thread.sleep(6000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
							try {
								 
								   driver.switchTo().defaultContent();
									driver.switchTo().frame("advisorDesktop");
									driver.switchTo().frame("cframe_ms__id46");
							} catch (Exception e3) {
								// TODO Auto-generated catch block
								System.out.println("Could Not Find Frame...");
								e3.printStackTrace();
							}
							try {
								return driver.findElement(locator);
								} catch (NoSuchElementException e2) {
									// TODO Auto-generated catch block
									System.out.println("Exception Occurred Researching Element Again . . ");
						
									return TestBase.explicitWaitHelper(driver, locator , waitTimer);
								}catch (Exception e) {
									e.printStackTrace();
									return null;
								}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	      
		
		
		
		
	}
	
	
	
	   
}
