package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;



public class CustomerSearchObject {
	//public static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	   // Customer Name Text Box
	   public static WebElement getCustomerNameText(WebDriver driver)
	   {
	     WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
		
	   //Customer System ID Text
	   public static WebElement getCustomerSystemIDText(WebDriver driver)
	   {
		   /*driver.switchTo().defaultContent();
		   driver.switchTo().frame("advisorDesktop");
		   driver.switchTo().frame("cframe_ms__id26");
	     WebElement element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[4]/td[3]/input[@name='Customer.CustomerId']"));
	      return element;*/
	      
	      
	      By locator = By.xpath("/html/body/form/table/tbody/tr[4]/td[3]/input[@name='Customer.CustomerId']");
		  try 
		  {driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id26");
			return driver.findElement(locator);
			} catch(NoSuchFrameException e1){
				System.out.println("Frame Not Found Exception Occured Researching Again . . .");
				try {
					Thread.sleep(6000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
				driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id26");
				
					return driver.findElement(locator);
				} catch(NoSuchFrameException e2){
					System.out.println("Frame Not Found  . . .");
					e2.printStackTrace();
					return null;
					
				}
				
				catch (NoSuchElementException e2) {
					// TODO Auto-generated catch block
					System.out.println("Exception Occurred Researching Element Again . . ");
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				
			}
		  
		  catch (NoSuchElementException e) {
			  
			  System.out.println("Exception Occurred Researching Element Again . . ");
			  return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	      
	      
	      
	      
	   }
	   

	   
	   //Customer Status dropdown
	   public static WebElement getCustomerStatusDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   //Customer Class dropdown
	   public static WebElement getCustomerClassDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	  
	   //Sales team Drop down
	   public static WebElement getSalesTeamDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   //Relationship Owner drop down
	   public static WebElement getRelationshipOwnerDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSearchCriteriaRadio(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSalesTeamGoButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getSearchButton(WebDriver driver)
	   {	
		   /*driver.switchTo().defaultContent();
		   driver.switchTo().frame("advisorDesktop");
		   driver.switchTo().frame("cframe_ms__id26");
		   WebElement element = driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr[1]/td[3]/input[@tabIndex='11']"));
	      return element; */
	      
	      By locator = By.xpath("/html/body/form/table[2]/tbody/tr[1]/td[3]/input[@tabIndex='11']");
	  		  try 
	  		  {driver.switchTo().defaultContent();
	  			driver.switchTo().frame("advisorDesktop");
	  			driver.switchTo().frame("cframe_ms__id26");
	  			return driver.findElement(locator);
	  			} catch(NoSuchFrameException e1){
	  				System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
	  				try {
	  					Thread.sleep(6000);
	  				} catch (InterruptedException e) {
	  					// TODO Auto-generated catch block
	  					e.printStackTrace();
	  				}
	  				
	  				try {
	  				driver.switchTo().defaultContent();
	  				driver.switchTo().frame("advisorDesktop");
	  				driver.switchTo().frame("cframe_ms__id26");
	  				
	  					return driver.findElement(locator);
	  				} catch(NoSuchFrameException e2){
						System.out.println("Frame Not Found  . . .");
						e2.printStackTrace();
						return null;
						
					}catch (NoSuchElementException e2) {
	  					// TODO Auto-generated catch block
	  					System.out.println("Exception Occurred Researching Element Again . . ");
	  					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
	  				}
	  				
	  			}
	  		  
	  		  catch (NoSuchElementException e) {
	  			System.out.println("Exception Occurred Researching Element Again . . ");
	  				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
	  			}
	  			catch (Exception e) {
	  				e.printStackTrace();
	  				return null;
	  			}
	  	      
	   } 
	   
	   public static WebElement getClearButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   

}
