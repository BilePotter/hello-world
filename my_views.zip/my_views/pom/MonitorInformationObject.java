package com.ibm.barclays.zeus.pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class MonitorInformationObject {
	
	//public static int waitTimer = 5;
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	public static WebElement getMIAddButton(WebDriver driver) {
		// TODO Auto-generated method stub
	
		//return driver.findElement(By.cssSelector("input#btnAddMonitor"));
		
		
		  By locator = By.cssSelector("input#btnAddMonitor");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getMonitorInformationDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#monitorInformation"));
		
		  By locator = By.cssSelector("select#monitorInformation");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getMonitorInformationButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#monitorInformationGo"));
		
		  By locator = By.cssSelector("input#monitorInformationGo");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getAccountTypeDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#accountTypeId"));
		
		  By locator = By.cssSelector("select#accountTypeId");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getAccountTypeButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#entityGo"));
		
		  By locator = By.cssSelector("input#entityGo");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getLinkFacilitiesURL(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("a#linkFacilities"));
		
		  By locator = By.cssSelector("a#linkFacilities");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static List<WebElement> getFacilitiesCheckBox(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElements(By.cssSelector("input#checkFacility"));
		
		  By locator = By.cssSelector("input#checkFacility");
	      try {
				
				return driver.findElements(locator);
			} catch (NoSuchElementException e) {
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return driver.findElements(locator);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getFacilitiesApplyButtonButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#btnapplyMonitor"));
		
		  By locator = By.cssSelector("input#btnapplyMonitor");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getFrequencyDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#frequency"));
		
		  By locator = By.cssSelector("select#frequency");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getFirstPeriodEndDate(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#firstPeriodEnd"));
		
		  By locator = By.cssSelector("input#firstPeriodEnd");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getPeroidCoveredDropDown(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("select#periodCovered"));
		
		  By locator = By.cssSelector("select#periodCovered");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getMISaveButton(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.cssSelector("input#saveBtn"));
		
		  By locator = By.cssSelector("input#saveBtn");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getMISavedID(WebDriver driver) {
		// TODO Auto-generated method stub
		//return driver.findElement(By.xpath("//form[@id='MonitorInformation']/table[1]/tbody[1]/tr[2]/td[4]"));
	
		  By locator = By.xpath("//form[@id='MonitorInformation']/table[1]/tbody[1]/tr[2]/td[4]");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	
	}

	public static WebElement getMIFrequencySaved(WebDriver driver) {
		// TODO Auto-generated method stub
	//return driver.findElement(By.xpath("//form[@id='MonitorInformation']/table[1]/tbody[1]/tr[2]/td[9]"));
	
	
	  By locator = By.xpath("//form[@id='MonitorInformation']/table[1]/tbody[1]/tr[2]/td[9]");
      try {
			
			return driver.findElement(locator);
		} catch (NoSuchElementException e) {
			return TestBase.explicitWaitHelper(driver, locator , waitTimer);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	
	}
	
	
	
	
	
	
	
}
