package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class GroupSummaryTabObject {
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	   public static WebElement getCustomerNameURL(WebDriver driver, String recordType)
	   {
	      WebElement element = driver.findElement(By.xpath("//"));
	      return element;
	   }
	   
	   
	  

}
