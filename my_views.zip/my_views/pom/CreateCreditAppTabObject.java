package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class CreateCreditAppTabObject {
	
	//public static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	   public static WebElement getBasisDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getPurposeDropDown(WebDriver driver)
	   {
		  /* driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id33");
		   driver.switchTo().frame("creditApp");
	     WebElement element = driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr[2]/td[2]/select[@type='select']"));
	 
		   return element;*/
		   
		   
		   By locator = By.xpath("/html/body/form/table[2]/tbody/tr[2]/td[2]/select[@type='select']");
		   
		   try 
			  {driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id33");
				driver.switchTo().frame("creditApp");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
					System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
					driver.switchTo().defaultContent();
					driver.switchTo().frame("advisorDesktop");
					driver.switchTo().frame("cframe_ms__id33");
					driver.switchTo().frame("creditApp");
						return driver.findElement(locator);
						
					} 
					catch (NoSuchFrameException e2){
						System.out.println("Could not Find Frame on Page . . ");
						e2.printStackTrace();
						return null;
						
					}
					catch (NoSuchElementException e2) {
						// TODO Auto-generated catch block
						System.out.println("Exception Occurred Researching Element Again . . ");
						
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					}catch (Exception e) {
						e.printStackTrace();
						return null;
					}
					
				}
			  
			  catch (NoSuchElementException e) {
				  System.out.println("Exception Occurred Researching Element Again . . ");
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
		   
		   
		   
		   
	   }
	   
	   public static WebElement getRequestDateText(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getKYCDropDown(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   }
	   
	   public static WebElement getRoutingIDText(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   
	   
	   public static WebElement getCreateButton(WebDriver driver)
	   {
		  /* driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id33");
		   driver.switchTo().frame("creditApp");
	      WebElement element = driver.findElement(By.xpath("/html/body/form/table[3]/tbody/tr/td[3]/input[@tabIndex='5']"));
	      return element;*/
	      
	      
	      
	      
	      By locator = By.xpath("/html/body/form/table[3]/tbody/tr/td[3]/input[@tabIndex='5']");
		   
		   try 
			  {driver.switchTo().defaultContent();
				driver.switchTo().frame("advisorDesktop");
				driver.switchTo().frame("cframe_ms__id33");
				driver.switchTo().frame("creditApp");
				return driver.findElement(locator);
				} catch(NoSuchFrameException e1){
					System.out.println("Frame Not Foudn Exception Occured Researching Again . . .");
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					try {
						driver.switchTo().defaultContent();
						driver.switchTo().frame("advisorDesktop");
						driver.switchTo().frame("cframe_ms__id33");
						driver.switchTo().frame("creditApp");
					
						return driver.findElement(locator);
					}
					catch (NoSuchFrameException e2){
						System.out.println("Could not Find Frame on Page . . ");
						e2.printStackTrace();
						return null;
						
					}
					catch (NoSuchElementException e2) {
						// TODO Auto-generated catch block
						System.out.println("Exception Occurred Researching Element Again . . ");
						return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					}catch (Exception e) {
						e.printStackTrace();
						return null;
					}
					
				}
			  
			  catch (NoSuchElementException e) {
					
					return TestBase.explicitWaitHelper(driver, locator , waitTimer);
				}
				catch (Exception e) {
					e.printStackTrace();
					return null;
				}
	      
	      
	      
	   } 

}
