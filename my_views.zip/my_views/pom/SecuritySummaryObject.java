package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class SecuritySummaryObject {
	
	//static int waitTimer = 5;
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	 public static WebElement getAddButton(WebDriver driver)
	   {
		 By locator = By.xpath("html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/div/form/table/tbody/tr/td[2]/input[@id='spnAdd']");
		 try {
			 driver.switchTo().defaultContent();
			 driver.switchTo().frame("advisorDesktop");
			 driver.switchTo().frame("cframe_ms__id61");
//			 WebElement element = driver.findElement(By.xpath("html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/div/form/table/tbody/tr/td[2]/input[@id='spnAdd']"));
//	      	return element;
			 return driver.findElement(locator);
			 
			} catch (NoSuchFrameException e1){
				
					try {
					Thread.sleep(5000);
					} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
					
					 try {driver.switchTo().defaultContent();
					 driver.switchTo().frame("advisorDesktop");
					 driver.switchTo().frame("cframe_ms__id61");

					 	
						 return driver.findElement(locator);
					 }catch (NoSuchFrameException e){
						 System.out.println("Could Not find Frame on Page. . ");
						 e.printStackTrace();
						 return null;
					 }
					 
					 catch (NoSuchElementException e) {
							return TestBase.explicitWaitHelper(driver, locator , waitTimer);
					}
					catch (Exception e) {
							e.printStackTrace();
							return null;
					}
				
			}

		 	catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	   }
	 
	 public static WebElement getDeleteButton(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("TBD"));
//	      return element;
		 
		 By locator = By.xpath("TBD");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	      
	   }
	 
	 public static WebElement getSaveButton(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[4]/tbody/tr[1]/td[4]/input[@type='image']"));
//	      return element;
	      
	      
	      //By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[4]/tbody/tr[1]/td[4]/input[@type='image']");
	      
		 By locator = By.xpath("//input[@type='image' and @tabIndex='43']");
		 try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
		
	 public static WebElement getAssetTypeDropdown(WebDriver driver)
	   {
	     
			
//		 WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr/td[3]/table/tbody/tr/td/select[@id='assetType']"));
//	      return element;
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr/td[3]/table/tbody/tr/td/select[@id='assetType']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	      
	   }
	 
	 public static WebElement getAssetTypeGoButton(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr/td[3]/table/tbody/tr/td/input[@id='assetTypeGoBtn']"));
//	      return element;
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr/td[3]/table/tbody/tr/td/input[@id='assetTypeGoBtn']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getBeneficiaryNameCheckBox(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[11]/td[2]/input[@id='BN5']"));
//	      return element;
//	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[11]/td[2]/input[@id='BN5']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getGoverningLawDropDown(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[10]/td[4]/select[@id='governingLaw']"));
//	      return element;
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[10]/td[4]/select[@id='governingLaw']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 public static WebElement getTrusteeDropDown(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[10]/td[2]/select[@id='trustee']"));
//	      return element;
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[10]/td[2]/select[@id='trustee']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getSecurityAmountTextBox(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[9]/td[2]/input[@type='text']"));
//	      return element;
	      
	      By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[9]/td[2]/input[@type='text']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getlinkedFacilitiesAddButton(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[3]/tbody/tr/td[2]/input[@type='image']"));
//	      return element;
	      
	    //  By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[3]/tbody/tr/td[2]//input[@type='image']");
		 By locator = By.xpath("//input[@type='image' and @alt='Add LinkedFacilities']"); 
		 try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getlinkedFacilitiesDeleteButton(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("TBD"));
//	      return element;
	      
	      By locator = By.xpath("TBD");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getlinkedFacilitiesDropDown(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[2]/tbody/tr[2]/td[2]/select[@id='linkedFacility']"));
//	      return element;
	      
	      //By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[2]/tbody/tr[2]/td[2]/select[@id='linkedFacility']");
	      
	      By locator = By.cssSelector("select[name='linkedFacilities.linkFacilitiesToSecurityForSave/1.linkFacilityToSecurityForSave'][id='linkedFacility']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }
	 
	 public static WebElement getlinkedFacilitiesCheckBox(WebDriver driver)
	   {
//	     WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[2]/tbody/tr[2]/td[1]/input[@id='row1Checkbox']"));
//	      return element;
	      
	      //By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table[2]/tbody/tr[2]/td[1]/input[@id='row1Checkbox']");
	     
		 By locator = By.cssSelector("input[name='linkedFacilities.linkFacilitiesToSecurityForSave/1.IsSelect'][id='row1Checkbox']");
		 try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	   }

	public static WebElement getValuationAmountText(WebDriver driver) {
//		WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[4]/td[4]/input[@id='valuationAmt']"));	
//		return element;
//		
		By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/form/table/tbody/tr[4]/td[4]/input[@id='valuationAmt']");
	      try {
				
				return driver.findElement(locator);
			} catch (NoSuchElementException e) {
				return TestBase.explicitWaitHelper(driver, locator , waitTimer);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	public static WebElement getSavedSecurity(WebDriver driver) {
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("advisorDesktop");
		driver.switchTo().frame("cframe_ms__id46");
		
		//WebElement element = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/div/form/table[2]/tbody/tr[2]/td[4]/a[text()='Agricultural']"));	
		
		By locator = By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/div/div/form/table[2]/tbody/tr[2]/td[4]/a[text()='Agricultural']");
		try {
			
			return driver.findElement(locator);
		} catch (NoSuchElementException e) {
			return TestBase.explicitWaitHelper(driver, locator , waitTimer);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	
}
