package com.ibm.barclays.zeus.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.utils.TestBase;

public class CustomerReportsTabObject {
	
	public static int waitTimer = Integer.parseInt(TestBase.getData("waitTimer"));
	
	   public static WebElement getCustomerCheckBox(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   
	   public static WebElement getClearButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getSelectAllButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getReportTypeRadio(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getSCARReportTypeRadio(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 
	   public static WebElement getGenerateButton(WebDriver driver)
	   {
	      WebElement element = driver.findElement(By.xpath("TBD"));
	      return element;
	   } 

}
