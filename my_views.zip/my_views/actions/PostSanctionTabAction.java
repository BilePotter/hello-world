package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.PostSanctionTabObject;

public class PostSanctionTabAction {
	
	public static void selectApplicationOutcome (WebDriver driver, WebElement element){
		
		element = PostSanctionTabObject.getApplicationOutcomeDropDown(driver);
		Select select1 = new Select(element);
		select1.selectByVisibleText("Customer Acceptance");
		

		
	}
	
public static void enterFurtherPostSanctionComments (WebDriver driver, WebElement element){
		
	element = PostSanctionTabObject.getFurtherPostSanctionCommentsTextBox(driver);
	element.sendKeys("Post Sanction Automated Comments");
		

		
	}

public static void performSave (WebDriver driver, WebElement element){
	
	element = PostSanctionTabObject.getSaveButton(driver);
	element.click();
	System.out.println("Post Sanction Completed Successfully");
	try {
		Thread.sleep(9000);
		} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
	
	try{
		driver.switchTo().alert().accept();
		} catch (NoAlertPresentException e ){
			System.out.println("Exception Occured for Alert Researching Alert Again. . .");
			
				try {
				Thread.sleep(6000);
				} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
				try {
					driver.switchTo().alert().accept();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					System.out.println("Alert Was not Valid this Time");
				}
			}
	catch (Exception e){
		e.printStackTrace();
	}
	

	
	
	//Alert message for Formula Monitors
	
	try {
		Thread.sleep(6000);
		} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
	
	try{
		driver.switchTo().alert().accept();
		} catch (NoAlertPresentException e ){
				System.out.println("Exception Occured for Alert Researching Alert Again. . .");
			
				try {
				Thread.sleep(6000);
				} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
				try {
					driver.switchTo().alert().accept();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					System.out.println("Alert Was not Valid this Time");
				}
			}
	
		catch (Exception e){
			e.printStackTrace();
		}
		
	}


}
