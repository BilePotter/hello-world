package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.CreateCreditAppTabObject;
import com.ibm.barclays.zeus.pom.MainPageObjects;

public class CreateCreditAppAction {
	
public static void execute (WebDriver driver, WebElement element){

		element = MainPageObjects.getCreateCATab(driver);
		element.click();
		element = CreateCreditAppTabObject.getPurposeDropDown(driver);
		Select oSelect = new Select(element);
		oSelect.selectByVisibleText("Customer Appeal");
		element = CreateCreditAppTabObject.getCreateButton(driver);
		element.click();
		System.out.println("Credit Application Created Successfully");
		
		
		try {
			Thread.sleep(5000);
			} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		
		try{
			driver.switchTo().alert().accept();
			} catch (NoAlertPresentException e ){
				System.out.println("Exception Occured for Alert Researching Alert Again. . .");
				
					try {
					Thread.sleep(6000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
					try {
						driver.switchTo().alert().accept();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						System.out.println("Alert was not valid this time");
					}
				}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
		try {
			Thread.sleep(9000);
			} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		
		try{
			driver.switchTo().alert().dismiss();
			} catch (NoAlertPresentException e ){
					System.out.println("Exception Occured for Alert Researching Alert Again. . .");
				
					try {
					Thread.sleep(8000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
						try {
							driver.switchTo().alert().dismiss();
						} catch (Exception e1) {
						// TODO Auto-generated catch block
						System.out.println("Alert was not valid this time");
						}
					}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
		
		
	}
}
