package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.PageHeaderObject;

public class HeaderAction {
	
	public static void clickCustomerSearch (WebDriver driver, WebElement element){

		element = PageHeaderObject.getCustomerSearchURL(driver);
		//SignInPageObject.getUserNameText();
		element.click();
		
	}
	
	public static void clickPortfolioReports (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickCreateCustomer (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickMNCDiary (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickTransferSupportUser (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickWindows (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickInbox (WebDriver driver, WebElement element){

		//write the code here
		
	}
	
	public static void clickLogout (WebDriver driver, WebElement element){

		
		element = PageHeaderObject.getLogoutURL(driver);
		
		element.click();
		
	}
	
	

}
