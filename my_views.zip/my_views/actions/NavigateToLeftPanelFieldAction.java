package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.MainPageObjects;

public class NavigateToLeftPanelFieldAction {
	
	public static void clickSecuritySummary (WebDriver driver, WebElement element){

		element = MainPageObjects.getSecuritySummaryURL(driver);
		element.click();
		System.out.println("Navigated to Security Summary Screen");
			
		
		
	}
	
	public static void clickGroupSummary (WebDriver driver, WebElement element){

		element = MainPageObjects.getGroupSummaryURL(driver);
		element.click();
		System.out.println("Navigated to Group Summary Screen");
		
		
	}
	
	public static void clickCustomerHistory (WebDriver driver, WebElement element){

		
		element = MainPageObjects.getCustomerHistoryURL(driver);
		element.click();
		System.out.println("Navigated to Customer History Screen");
		
	}
	
public static void clickCustomerInformation (WebDriver driver, WebElement element){

		
		element = MainPageObjects.getCustomerInfoURL(driver);
		element.click();
		System.out.println("Navigated to Customer Information Screen");
	}
public static void clickAlertUserSetup (WebDriver driver, WebElement element){

	
	element = MainPageObjects.getAlertUserURL(driver);
	element.click();
	System.out.println("Navigated to Alert User Screen");
	
}
	
	public static void facilitySummary (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void groupFacilitySummary (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void specialistGradingModels (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void gradingSummaryNHistory (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void propertySlotting (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void severity (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	
	
	public static void clickFormulaMonitors (WebDriver driver, WebElement element){

		//Write the code
		/*try {
			driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			MainPageObjects.getFormulaMonitorURL(driver).click();
			System.out.println("Navigated to Formula Monitors Setup Screen");
		} catch (NoSuchFrameException e) {
			// TODO Auto-generated catch block
			
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("advisorDesktop");
			driver.switchTo().frame("cframe_ms__id46");
			MainPageObjects.getFormulaMonitorURL(driver).click();
			System.out.println("Navigated to Formula Monitors Setup Screen");
			}catch (NoSuchFrameException e2){
				System.out.println("Could Not Find Frame on this Page . . ");
				e2.printStackTrace();
			}
		
		
		}*/
		
		
		MainPageObjects.getFormulaMonitorURL(driver).click();
		System.out.println("Navigated to Formula Monitors Setup Screen");
	}
	
	public static void inputActuals (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void mNCSummary (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void eWL (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void forbearance (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	public static void impairment (WebDriver driver, WebElement element){

		//Write the code
		
		
	}

	public static void clickMonitorInformation(WebDriver driver,
			WebElement element) {
		// TODO Auto-generated method stub
		
		MainPageObjects.getMonitorInfoURL(driver).click();
		System.out.println("Navigated to Monitors Information Setup Screen");
	
		
	}

	public static void clickGradingSummaryAndHistory(WebDriver driver,
			WebElement element) {
		// TODO Auto-generated method stub
		
		MainPageObjects.getGradingHistoryAndSummaryURL(driver).click();
		System.out.println("Navigated to Grading Summary Screen");
		
	}
	
	
	
	
	
	

}
