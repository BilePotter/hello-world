package com.ibm.barclays.zeus.actions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.SignInPageObject;

public class SignInAction {
	public static void execute (WebDriver driver, WebElement element){
	//public static void execute (WebDriver driver, WebElement element, ZeusDataObject data){
		element = SignInPageObject.getUserNameText(driver);
		//SignInPageObject.getUserNameText();
		
		
		
		element.sendKeys("1234561");
		
		/*element.sendKeys(data.getROLoginID());
		
		System.out.println(data.getROLoginID());*/
	}
	
	public static void executeExit (WebDriver driver, WebElement element){
		element = SignInPageObject.getExitButton(driver);
		element.click();
	}
	
public static void executeContinue (WebDriver driver, WebElement element){
	
		element = SignInPageObject.getContinueButton(driver);
		element.click();
		
		
	}


public static void verifyUserID (WebDriver driver, WebElement element){
	
	System.out.println("Verifying Login UserID for Current Session");
	element = SignInPageObject.getUserIDLoggedInText(driver);
	String actual = element.getText().substring(0, 7);
	//String expected = data.getROLoginID();
	String expected = "1234561";
	//System.out.println("Actual UserID Retireved "+ actual);
	Assert.assertTrue(actual.equals(expected));
	System.out.println("Login UserId: "+actual+" Verified for Current Session");
	
}


}
