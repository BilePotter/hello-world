package com.ibm.barclays.zeus.actions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.SecuritySummaryObject;

public class SecuritySummaryAction {
	
	public static void addSecurity (WebDriver driver, WebElement element){

		element = SecuritySummaryObject.getAddButton(driver);
		element.click();
		element = SecuritySummaryObject.getAssetTypeDropdown(driver);
		Select oSelect = new Select(element);
		oSelect.selectByVisibleText("Agricultural");
		element = SecuritySummaryObject.getAssetTypeGoButton(driver);
		element.click();
		element = SecuritySummaryObject.getValuationAmountText(driver);
		element.sendKeys("23456");
		element = SecuritySummaryObject.getSecurityAmountTextBox(driver);
		element.sendKeys("123");
		/*element = SecuritySummaryObject.getTrusteeDropDown(driver);
		Select oSelect1 = new Select(element);
		oSelect1.selectByVisibleText("Barclays Security Trustee");
		element = SecuritySummaryObject.getGoverningLawDropDown(driver);
		Select oSelect2 = new Select(element);
		oSelect2.selectByVisibleText("ABU DHABI");
		element = SecuritySummaryObject.getBeneficiaryNameCheckBox(driver);
		element.click();*/
		element = SecuritySummaryObject.getlinkedFacilitiesAddButton(driver);
		element.click();
		element = SecuritySummaryObject.getlinkedFacilitiesDropDown(driver);
		Select oSelect3 = new Select(element);
		oSelect3.selectByIndex(1);
		element = SecuritySummaryObject.getlinkedFacilitiesCheckBox(driver);
		element.click();
		
		element = SecuritySummaryObject.getSaveButton(driver);
		element.click();
		
		
	}
	
	public static void deleteSecurity (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void verifySecurityPresent (WebDriver driver, WebElement element){

		element = SecuritySummaryObject.getSavedSecurity(driver);
		String actualAsset = element.getText();
		
		String expectedAsset = "Agricultural";
		
		Assert.assertEquals(expectedAsset, actualAsset);
		
		
	}

}
