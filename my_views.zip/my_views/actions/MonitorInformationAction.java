package com.ibm.barclays.zeus.actions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.MonitorInformationObject;

public class MonitorInformationAction {

	public static String monitorInfoID;
	public static String mIFrequency;
	public static void clickAddButton (WebDriver driver, WebElement element){

		//Write the code
		MonitorInformationObject.getMIAddButton(driver).click();
		
	}
	

	
	public static void selectMonitorInformation (WebDriver driver, WebElement element){

		//Write the code
		new Select(MonitorInformationObject.getMonitorInformationDropDown(driver)).selectByVisibleText("Debenture Information");
		MonitorInformationObject.getMonitorInformationButton(driver).click();
	}
	
	public static void selectAccountType (WebDriver driver, WebElement element){

		//Write the code
		new Select(MonitorInformationObject.getAccountTypeDropDown(driver)).selectByVisibleText("Standalone");
		MonitorInformationObject.getAccountTypeButton(driver).click();
	}
	
	public static void linkFacilities (WebDriver driver, WebElement element){

		//Write the code
	
		MonitorInformationObject.getLinkFacilitiesURL(driver).click();
		
		// To Click on all facilities check-box
		for (WebElement checkboxElement : MonitorInformationObject.getFacilitiesCheckBox(driver)){
			checkboxElement.click();
		}
		
		//Click on Apply Button
		MonitorInformationObject.getFacilitiesApplyButtonButton(driver).click();	
	}
	
	public static void selectFrequency (WebDriver driver, WebElement element){
		new Select(MonitorInformationObject.getFrequencyDropDown(driver)).selectByVisibleText("M(Monthly)");
		
	}
	
	public static void setFirstPeriodEndDate (WebDriver driver, WebElement element){
		

		String modifiedDate= new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		(MonitorInformationObject.getFirstPeriodEndDate(driver)).sendKeys(modifiedDate);
		
	}
	
	public static void selectPeriodCovered (WebDriver driver, WebElement element){
		

		new Select(MonitorInformationObject.getPeroidCoveredDropDown(driver)).selectByVisibleText("Periodic");
		
	}
	
	
	public static void performSave (WebDriver driver, WebElement element){

		//Write the code
		MonitorInformationObject.getMISaveButton(driver).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		monitorInfoID = MonitorInformationObject.getMISavedID(driver).getText().trim();
		System.out.println("Monitor Information ID "+monitorInfoID+" Created and Recorded To be Utilized for Formula Monitor Selection and Back Date Function");
		mIFrequency = MonitorInformationObject.getMIFrequencySaved(driver).getText().trim();
		System.out.println("Monitor Information Frequency "+mIFrequency+" Created and Recorded To be Utilized for Back Date Function");
		System.out.println("Monitor Information Setup is Completed Successfully");
	}
	
	
	
}
