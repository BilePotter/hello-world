package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.CustomerInformationObject;

public class CustomerInformationAction {

	public static void verifyDRUFlag(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		//String value = new Select (CustomerInformationObject.getDRUFlagDropDown(driver)).getFirstSelectedOption().getText();
		//System.out.println(value);

		if (new Select (CustomerInformationObject.getDRUFlagDropDown(driver)).getFirstSelectedOption().getText().contentEquals("No")){
		new Select(CustomerInformationObject.getDRUFlagDropDown(driver)).selectByVisibleText("Yes");
		CustomerInformationObject.getCustomerInformationSaveButton(driver).click();
		}
		else
			System.out.println("DRU Flag Verified to be Already set to Yes for this Customer");
	}

}
