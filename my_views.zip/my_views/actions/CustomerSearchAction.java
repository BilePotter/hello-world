package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.CustomerSearchObject;
import com.ibm.barclays.zeus.pom.CustomerSearchResultsObject;

public class CustomerSearchAction {
	
	
	//public static void execute (WebDriver driver, WebElement element){
	public static void execute (WebDriver driver, WebElement element){
		
		element = CustomerSearchObject.getCustomerSystemIDText(driver);
		
		
		
		//System.out.println(TestBase.getTestCaseID());
		
		/*element.sendKeys(data.getCustSysID());
		
		System.out.println("Customer ID Retrived from DB as "+ data.getCustSysID()); */
		

		
		//element.sendKeys("1000001543");
		element.sendKeys("1000000752");
		
		
		//customer in CIT
		//element.sendKeys("7900000004");
		
		CustomerSearchObject.getSearchButton(driver).click();
			System.out.println("Clicked on Customer Search Button");
		
	}
	
public static void clickCustomerResult (WebDriver driver, WebElement element){
		
		element = CustomerSearchResultsObject.getCustomerNameURL(driver);
		element.click();	

		
	}

}
