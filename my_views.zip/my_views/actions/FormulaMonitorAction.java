package com.ibm.barclays.zeus.actions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.FormulaMonitorObject;

public class FormulaMonitorAction {

	
	public static String formulaMonitorID;
	public static String fMFrequency;
	public static void clickAddButton(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		FormulaMonitorObject.getFMAddButton(driver).click();
		
	}

	public static void selectMonitorType(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		
		new Select(FormulaMonitorObject.getMonitorTypeDropDown(driver)).selectByVisibleText("Covenant");
	}

	public static void selectCalculationType(WebDriver driver, WebElement element) {
		
		new Select(FormulaMonitorObject.getCalculationTypeDropDown(driver)).selectByVisibleText("Standard");
		FormulaMonitorObject.getCalculationTypeButton(driver).click();
	}

	
	public static void selectFormula(WebDriver driver, WebElement element) {
		
		new Select(FormulaMonitorObject.getCalculationTypeFormula(driver)).selectByVisibleText("Debenture");
		
		FormulaMonitorObject.getCalculationTypeFormulaGoButton(driver).click();
		
		FormulaMonitorObject.getCalculationTypeFormulaApplyButton(driver).click();
	}
	
	public static void linkFacilities(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		FormulaMonitorObject.getLinkFacilitiesURL(driver).click();
		
		
		List<WebElement> fmfacilities = FormulaMonitorObject.getFcailitiesCheckBoxes(driver);
		//to select all the facilities
		
		for (int count = 0; count< fmfacilities.size(); count ++){
			//Limiting the selection only till first 3 facilities from total
			if (count < 3)
				fmfacilities.get(count).click();
		
			//fmfacilities.get(1).click();
			//fmfacilities.get(2).click();
			}
		/*
		for (WebElement checkboxElement : fmfacilit
		ies){
			checkboxElement.click();
		}
		*/
		FormulaMonitorObject.getLinkFacilitiesGoButton(driver).click();
		
		
		//link monitor information
		
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FormulaMonitorObject.getLinkMonitorInfoCheckBox(driver, MonitorInformationAction.monitorInfoID).click();
		
		//click apply
		
		FormulaMonitorObject.getLinkFacilitiesApplyButton(driver).click();
	}

	
	public static void selectFrequency(WebDriver driver, WebElement element) {
		new Select(FormulaMonitorObject.getFormulaMonitorDetailsFrequencyDropDown(driver)).selectByVisibleText("M(Monthly)");
		
	}
	
	public static void setDebentureChargeID(WebDriver driver, WebElement element) {
		FormulaMonitorObject.getDebentureChargeIDTextBox(driver).sendKeys("1212132012");
		
	}
		
	public static void setFirstPeriodEndDate(WebDriver driver,
			WebElement element) {
		// TODO Auto-generated method stub
		Date date1 = new Date();
		String modifiedDate1= new SimpleDateFormat("dd/MM/yyyy").format(date1);
		//System.out.println(modifiedDate1);
		FormulaMonitorObject.getFormulaMonitorDetailsFirstPeriodEndDate(driver).sendKeys(modifiedDate1);
	}

	public static void selectCalculationBasis(WebDriver driver,
			WebElement element) {
		// TODO Auto-generated method stub
		
		new Select(FormulaMonitorObject.getFormulaMonitorDetailsCalculationBasis(driver)).selectByVisibleText("Periodic");
		FormulaMonitorObject.getFormulaMonitorDetailsCalculationBasisGoButton(driver).click();
	}

	public static void selectTargetCover(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		new Select(FormulaMonitorObject.getTargetCoverDropDown(driver)).selectByVisibleText("Standard");
		FormulaMonitorObject.getTargetCoverGoButton(driver).click();
	}

	public static void selectTypeOfCover(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		
	}

	public static void selectResultMustBe(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		new Select(FormulaMonitorObject.getResultMustBeDropDown(driver)).selectByVisibleText(">");
	}

	public static void setTimesCover(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		FormulaMonitorObject.getTimesCover(driver).sendKeys("10.00");
	}

	public static void performSave(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		FormulaMonitorObject.getFormulaMonitorSaveButton(driver).click();
		
		formulaMonitorID = FormulaMonitorObject.getFMSavedID(driver).getText().trim();
		System.out.println("Formula Monitor ID "+formulaMonitorID+" Created and Recorded To be Utilized for Back Date Function");
		fMFrequency = FormulaMonitorObject.getFMFrequencySaved(driver).getText().trim();
		System.out.println("Formula Monitor Frequency "+fMFrequency+" Created and Recorded To be Utilized for Back Date Function");
		System.out.println("Formula Monitor Setup Completed Successfully");
		
	}

}
