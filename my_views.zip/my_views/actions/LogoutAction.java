package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.PageHeaderObject;

public class LogoutAction {
	
	public static void execute (WebDriver driver, WebElement element){
		element = PageHeaderObject.getLogoutURL(driver);
		element.click();
		System.out.println("User Logged-out from Application Successfully");
		
		try {
			Thread.sleep(6000);
			} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		
		try{
			driver.switchTo().alert().accept();
			} catch (NoAlertPresentException e ){
				System.out.println("Exception Occured for Alert Researching Alert Again. . .");
				
					try {
					Thread.sleep(6000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
					
					try{
					driver.switchTo().alert().accept();
					}catch (NoAlertPresentException e1){
						System.out.println("Alert Was Not Valid this Time");
					}catch (Exception e1){
						e1.printStackTrace();
					}
				}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
		try {
			Thread.sleep(6000);
			} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		
		try{
			driver.switchTo().alert().accept();
			} catch (NoAlertPresentException e ){
				System.out.println("Exception Occured for Alert Researching Alert Again. . .");
				
					try {
					Thread.sleep(6000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
					try{
						driver.switchTo().alert().accept();
						}catch (NoAlertPresentException e1){
							System.out.println("Alert Was Not Valid this Time");
						}catch (Exception e1){
							e1.printStackTrace();
						}
				}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
	}

}
