package com.ibm.barclays.zeus.actions;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.AlertUserObject;
import com.ibm.barclays.zeus.utils.TestBase;
import org.apache.log4j.Logger;

public class AlertUserAction extends TestBase {
	
	public final static Logger log = Logger.getLogger(AlertUserAction.class.getName());
	
	public static void selectSupportUser (WebDriver driver, WebElement element){
		//driver.switchTo().defaultContent();
		//driver.switchTo().frame("advisorDesktop");
		//driver.switchTo().frame("cframe_ms__id33");
		new Select(AlertUserObject.getSupportUserDropDown(driver)).selectByVisibleText("G5 cov5");
		//element = driver.findElement(By.cssSelector("select#RMSUser"));
		//Select select = new Select(element); 
		//select.selectByVisibleText("G5 cov5");
		System.out.println("Support User Selected");
		
		
	}
	public static void selectCreditTeam (WebDriver driver, WebElement element){
		
		new Select(AlertUserObject.getCreditTeamDropDown(driver)).selectByVisibleText("Automation Credit Team");
			
		
	}
	
	public static void selectRCUTeam (WebDriver driver, WebElement element){

		new Select(AlertUserObject.getRCUTeamDropDown(driver)).selectByVisibleText("Automation RCU Team");
		AlertUserObject.getRCUTeamButton(driver).click();	
		
	}
	public static void selectRCUOwner (WebDriver driver, WebElement element){

		new Select(AlertUserObject.getRCUOwnerDropDown(driver)).selectByVisibleText("Aashutosh mittal");
		AlertUserObject.getRCUTeamButton(driver).click();	
		
	}
	
	public static void performSave (WebDriver driver, WebElement element){

		AlertUserObject.getSaveButton(driver).click();
		
	}
	
	public static Boolean verifyAlertSetupAlreadyExists (WebDriver driver, WebElement element){

		if ((new Select(AlertUserObject.getSupportUserDropDown(driver)).getFirstSelectedOption()) != null)
			return true;
		else
			return false;
		
	
		
	}
	
	
	
	
	
	


}
