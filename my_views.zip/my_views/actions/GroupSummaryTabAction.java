package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.SanctionTabObject;

public class GroupSummaryTabAction {
	
public static void selectLead (WebDriver driver, WebElement element){

		
		element = SanctionTabObject.getSanctionDecisionDropDown(driver);
		Select select1 = new Select(element);
		select1.selectByVisibleText("Sanction");
		
	}

}
