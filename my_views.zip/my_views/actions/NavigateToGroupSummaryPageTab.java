package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.MainPageObjects;

public class NavigateToGroupSummaryPageTab {
	
	public static void groupSummaryTab (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void documentsTab (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void ScoreCardTab (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void submitTab (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
	public static void SanctionTab (WebDriver driver, WebElement element){

		//Write the code
		element = MainPageObjects.getSanctionTab(driver);
		element.click();
		
		
		
	}
	
	public static void PostSanctionTab (WebDriver driver, WebElement element){

		element = MainPageObjects.getPostSanctionTab(driver);
		element.click();
		
	}
	
	public static void customerReportsTab (WebDriver driver, WebElement element){

		//Write the code
		
		
	}
	
}
