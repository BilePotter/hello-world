package com.ibm.barclays.zeus.actions;

import org.junit.Assert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.pom.CustomerHistoryObject;

public class CustomerHistoryAction {
	
	public static void selectCreditApp (WebDriver driver, WebElement element){

		element = CustomerHistoryObject.getDraftCAURL(driver);
		element.click();
		
		try {
			Thread.sleep(9000);
			} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		
		try{
			driver.switchTo().alert().dismiss();
			} catch (NoAlertPresentException e ){
				System.out.println("Exception Occured for Alert Researching Alert Again. . .");
				
					try {
					Thread.sleep(8000);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
					try {
						driver.switchTo().alert().dismiss();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						System.out.println("Alert was not valid this time");
					}
				}
			catch (Exception e){
			e.printStackTrace();
			}
		
	}
	
	public static void selectSanctionedCreditApp (WebDriver driver, WebElement element){

		element = CustomerHistoryObject.getSanctionedCAURL(driver);
		element.click();
			
		
	}
	
	public static void verifyCreditAppStatusSanctioned (WebDriver driver, WebElement element){

		element = CustomerHistoryObject.getSanctionedCAURL(driver);
		String expected = "Sanction";
		String actual = element.getText();
		Assert.assertEquals(expected,actual);
		
	}

}
