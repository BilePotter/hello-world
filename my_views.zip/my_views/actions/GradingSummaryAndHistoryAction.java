package com.ibm.barclays.zeus.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.ibm.barclays.zeus.pom.GradingSummaryAndHistoryObject;

public class GradingSummaryAndHistoryAction {

	public static void applyGradingModel(WebDriver driver, WebElement element) {
		// TODO Auto-generated method stub
		if (GradingSummaryAndHistoryObject.getUngradedCheckBox(driver).isSelected()){
			
			GradingSummaryAndHistoryObject.getRatingAgencyCheckBox(driver).click();
			
			new Select(GradingSummaryAndHistoryObject.getRatingAgencyDropDown(driver)).selectByVisibleText("Moody's");
			GradingSummaryAndHistoryObject.getRatingAgencyGoButton(driver).click();
			
			
			new Select(GradingSummaryAndHistoryObject.getRatingAgencyPITDropDown(driver)).selectByVisibleText("A1");
			
			new Select(GradingSummaryAndHistoryObject.getGradeEquivalentPITDropDown(driver)).selectByVisibleText("2");
			
			new Select(GradingSummaryAndHistoryObject.getGradeEquivalentTTCDropDown(driver)).selectByVisibleText("2");
			
			GradingSummaryAndHistoryObject.getSaveGradesButton(driver).click();
			}
			else{
				
				System.out.println("Grading is already Applied for this customer");
			
			}
	}

}
