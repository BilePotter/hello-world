package com.ibm.barclays.zeus.actions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.ibm.barclays.zeus.utils.DBBackDateMIFMUtil;

public class BackDateMIFMAction {
	
	public static void backDateMI(String mIID, String frequency) {
		
		DBBackDateMIFMUtil test1 = new DBBackDateMIFMUtil();
		Calendar calNow1 = Calendar.getInstance();
		if (frequency.contains("Monthly")){
			// adding -3 month
			calNow1.add(Calendar.MONTH, -3);	
		}
		else if (frequency.contains("Year")){
			// adding -3 Year
			calNow1.add(Calendar.YEAR, -3);	
		}
		else if (frequency.contains("Quarterly")){
			// adding -3 Quarters
			calNow1.add(Calendar.MONTH, -9);	
		}
		

		// fetching updated time
		Date dateBeforeAMonth = calNow1.getTime();
		String modifiedDate1= new SimpleDateFormat("dd-MMM-yy").format(dateBeforeAMonth);
		
		
		System.out.println("Back date for MI Retrieved as "+modifiedDate1);	

		try {
			Boolean flag = test1.backDateMIFM("MI", mIID, modifiedDate1);
		
			if (flag)
				System.out.println("Record with MI ID:"+mIID+" Updated Successfully..");
			else
			System.out.println("Record update Failed for MI ID:"+mIID);
			} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
		//once job done make instance null
		//test1 = null;
			}
	
	public static void backDateFM(String fMID, String frequency){
		
		DBBackDateMIFMUtil test = new DBBackDateMIFMUtil();
		Calendar calNow = Calendar.getInstance();
		if (frequency.contains("Monthly")){
			// adding -3 month
			calNow.add(Calendar.MONTH, -3);	
		}
		else if (frequency.contains("Year")){
			// adding -3 Year
			calNow.add(Calendar.YEAR, -3);	
		}
		else if (frequency.contains("Quarterly")){
			// adding -3 Quarter
			calNow.add(Calendar.MONTH, -9);	
		}
		

		// fetching updated time
		Date dateBeforeAMonth = calNow.getTime();
		
		
		String modifiedDate= new SimpleDateFormat("dd-MMM-yy").format(dateBeforeAMonth);
		System.out.println("Back date for FM Retrieved as "+modifiedDate);	

		try {
			Boolean flag = test.backDateMIFM("FM", fMID, modifiedDate);
		
			if (flag)
				System.out.println("Record with FM ID:"+fMID+" Updated Successfully..");
			else
			System.out.println("Record update Failed for FM ID:"+fMID);
			} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
		//once job done make instance null
		//test = null;
	}
	

}
