package com.ibm.barclays.zeus.test;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ibm.barclays.zeus.actions.AlertUserAction;
import com.ibm.barclays.zeus.actions.BackDateMIFMAction;
import com.ibm.barclays.zeus.actions.CreateCreditAppAction;
import com.ibm.barclays.zeus.actions.CustomerHistoryAction;
import com.ibm.barclays.zeus.actions.CustomerInformationAction;
import com.ibm.barclays.zeus.actions.CustomerSearchAction;
import com.ibm.barclays.zeus.actions.FormulaMonitorAction;
import com.ibm.barclays.zeus.actions.GradingSummaryAndHistoryAction;
import com.ibm.barclays.zeus.actions.HeaderAction;
import com.ibm.barclays.zeus.actions.MonitorInformationAction;
import com.ibm.barclays.zeus.actions.NavigateToGroupSummaryPageTab;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.actions.PostSanctionTabAction;
import com.ibm.barclays.zeus.actions.SanctionTabAction;
import com.ibm.barclays.zeus.actions.SignInAction;
import com.ibm.barclays.zeus.utils.TestBase;

@Listeners(com.ibm.barclays.zeus.utils.Listener.class)
public class TestCase02 extends TestBase {
	
	WebElement element = null;
	public String testMethodName = null;
	
	@BeforeClass
	public void setUP(){
		
		System.out.println("#############Execution Started for Test Case 02##################");
		System.out.println(" ");
		
		init();
	  

	}
	
	@AfterClass
	public void rollOff(){
		
	
        System.out.println("#############Execution Completed for Test Case 02##################");
        System.out.println(" ");
        driver.quit();
        driver = null;
	}
	
	@BeforeMethod
	 public void beforeTestMethod(Method testMethod){
	   testMethodName=testMethod.getName();       
	 }
	
	@Test
	public void testCase02_VerifyMonitorInformationAndFormulaMonitorFunctionality (){
		
		// Feed in SIT URL
		driver.get(TestBase.getData("TestCases.Environment.URL"));

		driver.manage().window().maximize();

		
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(TestBase.getData("TestCases.ImplicitWait.Seconds")), TimeUnit.SECONDS);
		driver.navigate().to("javascript:document.getElementById('overridelink').click()");
		
		SignInAction.execute(driver, element);
		SignInAction.executeContinue(driver, element);
		
		//Customer Search
		HeaderAction.clickCustomerSearch(driver, element);
		CustomerSearchAction.execute(driver, element);
		//CustomerSearchAction.execute(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		CustomerSearchAction.clickCustomerResult(driver, element);

		//Create Credit App
		
		CreateCreditAppAction.execute(driver, element);
		
		//Setup Alert or Verify if Already Setup
		
		NavigateToLeftPanelFieldAction.clickAlertUserSetup(driver, element);
		
		
		
		//Thread.sleep(1000);
		if(AlertUserAction.verifyAlertSetupAlreadyExists(driver, element))
		System.out.println("Alert Setup Already Exists for this Customer");
		else{
			AlertUserAction.selectSupportUser(driver, element);
			AlertUserAction.selectCreditTeam(driver, element);
			AlertUserAction.selectRCUTeam(driver, element);
			AlertUserAction.selectRCUOwner(driver, element);
			AlertUserAction.performSave(driver, element);
			System.out.println("Alert Setup is Done Successfully and Saved");
		}
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		//Sample Test To TakeScreen on Failure
				//Assert.assertTrue(false);
		
		//Monitor Information is Configured
		
		   NavigateToLeftPanelFieldAction.clickMonitorInformation(driver,element);
		   MonitorInformationAction.clickAddButton(driver, element);
		   MonitorInformationAction.selectMonitorInformation(driver, element);
		   MonitorInformationAction.selectAccountType(driver, element);
		   MonitorInformationAction.linkFacilities(driver, element);
		   MonitorInformationAction.selectFrequency(driver, element);
		   MonitorInformationAction.setFirstPeriodEndDate(driver, element);
		   MonitorInformationAction.selectPeriodCovered(driver, element);
		   MonitorInformationAction.performSave(driver, element);
		   
		   getScreenShotOnProgress(driver, Result, testMethodName); 
		   //Formula Monitors is configured for customer
			
		    NavigateToLeftPanelFieldAction.clickFormulaMonitors(driver, element);
		    FormulaMonitorAction.clickAddButton(driver,element);
		    FormulaMonitorAction.selectMonitorType(driver,element);
		    FormulaMonitorAction.selectCalculationType(driver,element);
		    FormulaMonitorAction.selectFormula(driver, element);
		    FormulaMonitorAction.linkFacilities(driver,element);
		    FormulaMonitorAction.selectFrequency(driver, element);
		    FormulaMonitorAction.setDebentureChargeID(driver, element);
		    FormulaMonitorAction.setFirstPeriodEndDate(driver, element);
		    FormulaMonitorAction.selectCalculationBasis(driver, element);
		    FormulaMonitorAction.selectTargetCover(driver, element);
		    //FormulaMonitorAction.selectTypeOfCover(driver, element);
		    FormulaMonitorAction.selectResultMustBe(driver, element);
		    FormulaMonitorAction.setTimesCover(driver, element);
		    FormulaMonitorAction.performSave(driver, element);
		    getScreenShotOnProgress(driver, Result, testMethodName);
		   
		   //Grading Summary and History is Applied
		    

			NavigateToLeftPanelFieldAction.clickGradingSummaryAndHistory(driver, element);
		   GradingSummaryAndHistoryAction.applyGradingModel(driver,element);
		   getScreenShotOnProgress(driver, Result, testMethodName);
		   
		   // DRU FLAG is Yes at Customer Information Screen
		   
			NavigateToLeftPanelFieldAction.clickCustomerInformation(driver, element);
			CustomerInformationAction.verifyDRUFlag(driver,element);
			getScreenShotOnProgress(driver, Result, testMethodName);
			
			//user navigates to Customer History
			
			
			NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		
			
		   //Credit App is Selected
			
			CustomerHistoryAction.selectCreditApp(driver, element);
			
		   //navigates to Sanction tab
			
			NavigateToGroupSummaryPageTab.SanctionTab(driver, element);
			
		   //Sanctioner comments are entered
			
			SanctionTabAction.enterSanctionerComments(driver, element);
			
		   //sanction decision is selected
			
			SanctionTabAction.selectSanctionDecision(driver, element);
			
			getScreenShotOnProgress(driver, Result, testMethodName);
		   //user saves sanction details
			SanctionTabAction.performSave(driver, element);
			
		   //user performs post sanction
			NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		
			CustomerHistoryAction.selectSanctionedCreditApp(driver, element);
			NavigateToGroupSummaryPageTab.PostSanctionTab(driver, element);
			PostSanctionTabAction.selectApplicationOutcome(driver, element);
			PostSanctionTabAction.enterFurtherPostSanctionComments(driver, element);
			
			getScreenShotOnProgress(driver, Result, testMethodName);
			
			PostSanctionTabAction.performSave(driver, element);
			System.out.println("Post Sanction Saved");
			
		   
			
		  // Actual Date is Back-dated for MI FM
			BackDateMIFMAction.backDateMI(MonitorInformationAction.monitorInfoID, MonitorInformationAction.mIFrequency);
		    BackDateMIFMAction.backDateFM(FormulaMonitorAction.formulaMonitorID, FormulaMonitorAction.fMFrequency);
		   
		    //User clicks on Logout
			
			//LogoutAction.execute(driver, element);
			
			getScreenShotOnProgress(driver, Result, testMethodName);
		
		
		
		
	}


}
