
	package com.ibm.barclays.zeus.test;

	import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.ibm.barclays.zeus.actions.CreateCreditAppAction;
import com.ibm.barclays.zeus.actions.CustomerHistoryAction;
import com.ibm.barclays.zeus.actions.CustomerSearchAction;
import com.ibm.barclays.zeus.actions.HeaderAction;
import com.ibm.barclays.zeus.actions.LogoutAction;
import com.ibm.barclays.zeus.actions.NavigateToGroupSummaryPageTab;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.actions.PostSanctionTabAction;
import com.ibm.barclays.zeus.actions.SanctionTabAction;
import com.ibm.barclays.zeus.actions.SecuritySummaryAction;
import com.ibm.barclays.zeus.actions.SignInAction;

	import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

	public class TestCase01Copy {
		
		
			//public  WebDriver driver = DriverFactory.getInstance().openBrowser();
			//public  WebDriver driver;
			WebDriver driver;
			WebElement element = null;
			URL hubURL = null;
			
			
			@BeforeClass
			public void init(){
				/*
			String service = "C:\\jars\\IEDriverServer_Win32_2.53.0\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", service);
			driver = new InternetExplorerDriver(); */
				
				try {
					// get hub URL specified in the TestNG XML test suite file
					// if not provided then use default http://localhost:4444/wd/hub
					//hubURL = new URL("http://10.44.203.156:4445/wd/hub");
					
					hubURL = new URL("http://localhost:4445/wd/hub");
					
					} catch (MalformedURLException e) {
					System.out.println("ex:\n" + e.getMessage() + "");
					e.printStackTrace();
					}
				
				String service = "C:\\jars\\IEDriverServer_Win32_2.53.0\\IEDriverServer.exe";
				System.setProperty("webdriver.ie.driver", service);
				DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
				capability.setBrowserName("internet explorer");
				capability.setPlatform(Platform.WINDOWS);
				driver = new RemoteWebDriver(hubURL, capability);
				
				
				
				//WebDriver driver = RemoteDriverFactory.createInstance(hubURL, browserName);
				//DriverManager.setWebDriver(driver);
			
			}
			
			@AfterClass
			public void rollOff(){
				driver.quit();
	            driver = null;
			}
		
		
		@Test (priority =0)
		public void zeusURLIsLoadedWithoutData() {
			
			//SIT
			driver.get("https://ylht.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
			
			//CIT
			//driver.get("https://yolt.wload.barclays.co.uk:51200/Advisor/servlet/RequestHandler?ActionID=Login");
			driver.manage().window().maximize();
			//UAT
			//driver.get("https://yk7t.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.navigate().to("javascript:document.getElementById('overridelink').click()");
			

			
		}
		
		@Test (priority=1)
		public void UserNameIsEntered(){
			SignInAction.execute(driver, element);
			//SignInAction.execute(driver, element);
		}
		
		@Test (priority=2)
		public void ContinueButtonisClicked(){
			SignInAction.executeContinue(driver, element);
		}
		
		@Test (priority=3)
		public void desiredCustomerIsSearched() {
			HeaderAction.clickCustomerSearch(driver, element);
			CustomerSearchAction.execute(driver, element);
			//CustomerSearchAction.execute(driver, element);
			CustomerSearchAction.clickCustomerResult(driver, element);

			
		}
		@Test (priority=4)
		public void creditApplicationIsCreated() {
			
			CreateCreditAppAction.execute(driver, element);

		}
		
		
		
		@Test (priority=5)
		public void userNavigatesToCustomerHistory(){
			
			
			NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
			System.out.println("Navigated to CustomerHistory");
			
		}
		@Test (priority=6)
		public void creditAppIsSelected(){
		
		CustomerHistoryAction.selectCreditApp(driver, element);
		}

		@Test (priority=7)
		public void userNavigatesToSecuritySummaryScreen() {
		
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);

		}
		@Test (priority=8)
		public void addsSecurityByLinkingFacility() {
		
		SecuritySummaryAction.addSecurity(driver, element);

		}

		@Test (priority=9)
		public void userNavigatesToGroupSummary() {
		
		NavigateToLeftPanelFieldAction.clickGroupSummary(driver, element);

		}
		
		

		@Test (priority=10)
		public void sanctionerCommentsAreEntered() {
			NavigateToGroupSummaryPageTab.SanctionTab(driver, element);
		SanctionTabAction.enterSanctionerComments(driver, element);

		}

		@Test (priority=11)
		public void sanctionDecisionIsSelected() {
		
		SanctionTabAction.selectSanctionDecision(driver, element);

		}

		@Test (priority=12)
		public void userSavesSanctionDetails() {
		
			SanctionTabAction.performSave(driver, element);

		}

		
		@Test (priority=13)
		public void userPerformsPostSanction() {
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		System.out.println("Navigated to CustomerHistory");
		CustomerHistoryAction.selectSanctionedCreditApp(driver, element);
		NavigateToGroupSummaryPageTab.PostSanctionTab(driver, element);
		PostSanctionTabAction.selectApplicationOutcome(driver, element);
		PostSanctionTabAction.enterFurtherPostSanctionComments(driver, element);
		PostSanctionTabAction.performSave(driver, element);
		System.out.println("Post Sanction Saved");

		}


		@Test (priority=14)
		public void UserIsAbleToLogin(){
		
		System.out.println("Verifying UserID Logged In with");
		SignInAction.verifyUserID(driver, element);
		System.out.println("Verified User ID");
		
		
		}

		@Test (priority=15)	
		public void CreditApplicationIsPresentInSanctionStatusInCustomerHistory () {
		
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		//do it one more time to refresh the page
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		CustomerHistoryAction.verifyCreditAppStatusSanctioned(driver, element);
		}

		@Test (priority=16)
		public void userIsAbleToSeeSavedSecurityInSecuritySummary(){
		
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);
		SecuritySummaryAction.verifySecurityPresent(driver, element);
		
		}

		@Test (priority=17)
		public void userClicksOnLogout(){
			LogoutAction.execute(driver, element);
		
		}
	
}
