package com.ibm.barclays.zeus.test;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import com.ibm.barclays.zeus.actions.CreateCreditAppAction;
import com.ibm.barclays.zeus.actions.CustomerHistoryAction;
import com.ibm.barclays.zeus.actions.CustomerSearchAction;
import com.ibm.barclays.zeus.actions.HeaderAction;
import com.ibm.barclays.zeus.actions.LogoutAction;
import com.ibm.barclays.zeus.actions.NavigateToGroupSummaryPageTab;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.actions.PostSanctionTabAction;
import com.ibm.barclays.zeus.actions.SanctionTabAction;
import com.ibm.barclays.zeus.actions.SecuritySummaryAction;
import com.ibm.barclays.zeus.actions.SignInAction;
import com.ibm.barclays.zeus.utils.TestBase;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.apache.log4j.Logger;


@Listeners(com.ibm.barclays.zeus.utils.Listener.class)
public class TestCase01 extends TestBase {
	
	public static final Logger log = Logger.getLogger(TestCase01.class.getName());

		WebElement element = null;
		public String testMethodName = null;
		
		@BeforeClass
		public void setUP(){
			
			System.out.println("#############Execution Started for Test Case 01##################");
			System.out.println(" ");
			init();
		    
		
		}
		
		@AfterClass
		public void rollOff(){
	
            System.out.println("#############Execution Completed for Test Case 01##################");
            log.info("=========== Finished Test Case01 Test=============");
            System.out.println(" ");
            driver.quit();
            driver = null;
		}
		
		 @BeforeMethod
		 public void beforeTestMethod(Method testMethod){
		   testMethodName=testMethod.getName();       
		 }
	
	
	@Test (priority =0)
	public void testCase01_VerifyUserIsAbleToAddSecurityInZeus() {
		

		driver.get(TestBase.getData("TestCases.Environment.URL"));

		driver.manage().window().maximize();
		
		
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(TestBase.getData("TestCases.ImplicitWait.Seconds")), TimeUnit.SECONDS);
		
		
		driver.navigate().to("javascript:document.getElementById('overridelink').click()");

	
		SignInAction.execute(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		SignInAction.executeContinue(driver, element);
	

		getScreenShotOnProgress(driver, Result, testMethodName);
		
		//Search Customer
		HeaderAction.clickCustomerSearch(driver, element);
		CustomerSearchAction.execute(driver, element);
		//CustomerSearchAction.execute(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		CustomerSearchAction.clickCustomerResult(driver, element);
		 
		
		//Sample Test To TakeScreen on Failure
		//Assert.assertTrue(false);

		//Create Credit Application
		CreateCreditAppAction.execute(driver, element);
		
		//Navigate to Customer History and Select Credit App
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		CustomerHistoryAction.selectCreditApp(driver, element);
		
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);
		//Add Security Summary
		SecuritySummaryAction.addSecurity(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		//Sanction Credit App
		NavigateToLeftPanelFieldAction.clickGroupSummary(driver, element);
		NavigateToGroupSummaryPageTab.SanctionTab(driver, element);
		SanctionTabAction.enterSanctionerComments(driver, element);
		SanctionTabAction.selectSanctionDecision(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		SanctionTabAction.performSave(driver, element);

		//Post Sanction
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		CustomerHistoryAction.selectSanctionedCreditApp(driver, element);
		NavigateToGroupSummaryPageTab.PostSanctionTab(driver, element);
		PostSanctionTabAction.selectApplicationOutcome(driver, element);
		PostSanctionTabAction.enterFurtherPostSanctionComments(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		PostSanctionTabAction.performSave(driver, element);
		System.out.println("Post Sanction Saved");
		
		
		//Verify Current Login UserID
		SignInAction.verifyUserID(driver, element);
	
	
		//Verify CA Status
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		//do it one more time to refresh the page
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		CustomerHistoryAction.verifyCreditAppStatusSanctioned(driver, element);
		
		getScreenShotOnProgress(driver, Result, testMethodName);
	


		//Verify Security is Setup
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);
		//SecuritySummaryAction.verifySecurityPresent(driver, element);
		getScreenShotOnProgress(driver, Result, testMethodName);
		
		//Logout
		//LogoutAction.execute(driver, element);

	
	}
	

}
