package com.ibm.barclays.zeus.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.CustomerSearchAction;
import com.ibm.barclays.zeus.actions.HeaderAction;
import com.ibm.barclays.zeus.utils.DriverFactory;
import com.ibm.barclays.zeus.utils.ZeusDataFactory;
import com.ibm.barclays.zeus.utils.ZeusDataObject;

import cucumber.api.java.en.Given;

public class CustomerSearch {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	//public  WebDriver driver;
	WebElement element = null;
	public ZeusDataObject data = ZeusDataFactory.getInstance().getZeusData();


		
	@Given ("^desired customer is searched$")
	public void desiredCustomerIsSearched() {
		HeaderAction.clickCustomerSearch(driver, element);
		CustomerSearchAction.execute(driver, element);
		//CustomerSearchAction.execute(driver, element);
		CustomerSearchAction.clickCustomerResult(driver, element);

		
	}


}
