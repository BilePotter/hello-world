package com.ibm.barclays.zeus.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.LogoutAction;
import com.ibm.barclays.zeus.utils.DriverFactory;

import cucumber.api.java.en.Then;

public class ZeusLogOut {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();

	WebElement element = null;
	
	@Then ("^User clicks on Logout$")
	public void userClicksOnLogout(){
	LogoutAction.execute(driver, element);
		
	}


}
