package com.ibm.barclays.zeus.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.CreateCreditAppAction;
import com.ibm.barclays.zeus.utils.DriverFactory;

import cucumber.api.java.en.Given;

public class CreateCreditApp {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	//public  WebDriver driver;
	WebElement element = null;


		
	@Given ("^Credit Application is Created$")
	public void creditApplicationIsCreated() {
	
		CreateCreditAppAction.execute(driver, element);

	}

}
