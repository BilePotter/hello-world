package com.ibm.barclays.zeus.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.SignInAction;
import com.ibm.barclays.zeus.utils.DriverFactory;
import com.ibm.barclays.zeus.utils.TestBase;
import com.ibm.barclays.zeus.utils.ZeusDataFactory;
import com.ibm.barclays.zeus.utils.ZeusDataObject;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ZeusLogin {


	
	//public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	public  WebDriver driver;
	public ZeusDataObject data; 
WebElement element = null;

	//public static String TestCaseID;

	
@Given ("^Zeus URL is loaded for \"(.*)\"$")
public void zeusURLIsLoaded(String TestCaseID1) {
	
	
	//Use below  section to initialise the test data from DB
	TestBase.setTestCaseID(TestCaseID1);
	System.out.println("Execution Started for" +TestCaseID1);
	//Retrieve data from DB for your TestCase
	data= ZeusDataFactory.getInstance().getZeusData(); 
	

	//To Open SIT URL
	driver.get("https://ylht.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
	driver.manage().window().maximize();
	
	//UAT
	//driver.get("https://yk7t.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	driver.navigate().to("javascript:document.getElementById('overridelink').click()");

	
}

@Given ("^Zeus URL is loaded$")
public void zeusURLIsLoadedWithoutData() {
	
	//SIT
	driver.get("https://ylht.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
	
	//CIT
	//driver.get("https://yolt.wload.barclays.co.uk:51200/Advisor/servlet/RequestHandler?ActionID=Login");
	driver.manage().window().maximize();
	//UAT
	//driver.get("https://yk7t.wload.barclays.co.uk:58300/Advisor/servlet/RequestHandler?ActionID=Login");
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	driver.navigate().to("javascript:document.getElementById('overridelink').click()");

	
}

@When ("^Username is Entered$")
public void UserNameIsEntered(){
	SignInAction.execute(driver, element);
	//SignInAction.execute(driver, element);
}

@When ("^Continue Button is Clicked$")
public void ContinueButtonisClicked(){
	SignInAction.executeContinue(driver, element);
}


@Then ("^User is able to login User ID appears on page$")
public void UserIsAbleToLogin(){
	
	System.out.println("Verifying UserID Logged In with");
	SignInAction.verifyUserID(driver, element);
	System.out.println("Verified User ID");
	
	
}

@When ("^Exit Button is Clicked$")
public void AndExitButtonisClicked(){
	SignInAction.executeExit(driver, element);
	
}

@When("^Customer's RO is Logged-in Back$")
public void customer_s_RO_is_Logged_in_Back() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}


@When("^Appropriate RCU User is Logged-In to Inbox$")
public void appropriate_RCU_User_is_Logged_In_to_Inbox() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^Appropriate Credit User is Logged-In to Inbox$")
public void appropriate_Credit_User_is_Logged_In_to_Inbox() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Before
public void beforeScenario() {
	driver = DriverFactory.getInstance().openBrowser();
	
    System.out.println("this will run before the actual scenario");
}

/*
@After
public void afterScenario() {
	DriverFactory.makeInstancenull();
    System.out.println("this will run after scneario is finished, even if it failed");
}

*/

}
