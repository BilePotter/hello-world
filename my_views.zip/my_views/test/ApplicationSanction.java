package com.ibm.barclays.zeus.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.CustomerHistoryAction;
import com.ibm.barclays.zeus.actions.NavigateToGroupSummaryPageTab;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.actions.PostSanctionTabAction;
import com.ibm.barclays.zeus.actions.SanctionTabAction;
import com.ibm.barclays.zeus.utils.DriverFactory;

import cucumber.api.java.en.Given;

public class ApplicationSanction {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	//public  WebDriver driver;
	WebElement element = null;
	
	@Given ("^navigates to Sanction tab$")
	public void navigatesToSanctionTab() {
	
		NavigateToGroupSummaryPageTab.SanctionTab(driver, element);
	}
	
	
	@Given ("^sanctioner comments are entered$")
	public void sanctionerCommentsAreEntered() {
	
		SanctionTabAction.enterSanctionerComments(driver, element);

	}
	
	
	@Given ("^sanction decision is selected$")
	public void sanctionDecisionIsSelected() {
	
		SanctionTabAction.selectSanctionDecision(driver, element);

	}
	
	
	@Given ("^user saves sanction details$")
	public void userSavesSanctionDetails() {
	
	SanctionTabAction.performSave(driver, element);

	}
	

	@Given ("^user performs post sanction$")
	public void userPerformsPostSanction() {
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		System.out.println("Navigated to CustomerHistory");
		CustomerHistoryAction.selectSanctionedCreditApp(driver, element);
		NavigateToGroupSummaryPageTab.PostSanctionTab(driver, element);
		PostSanctionTabAction.selectApplicationOutcome(driver, element);
		PostSanctionTabAction.enterFurtherPostSanctionComments(driver, element);
		PostSanctionTabAction.performSave(driver, element);
		System.out.println("Post Sanction Saved");

	}

}
