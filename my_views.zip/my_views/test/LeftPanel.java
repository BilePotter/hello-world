package com.ibm.barclays.zeus.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.CustomerHistoryAction;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.actions.SecuritySummaryAction;
import com.ibm.barclays.zeus.utils.DriverFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LeftPanel {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	//public  WebDriver driver;
	WebElement element = null;

	
	@Given ("^user navigates to Security Summary Screen$")
	public void userNavigatesToSecuritySummaryScreen() {
	
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);

	}
	
	
	
	@Given("^user navigates to Customer History$")
	public void userNavigatesToCustomerHistory(){
		
		
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		System.out.println("Navigated to CustomerHistory");
		
	}
	
	
	@Given("^Credit App is Selected$")
	public void creditAppIsSelected(){
		
		CustomerHistoryAction.selectCreditApp(driver, element);
	}
	
	@Given ("^adds security by linking facility$")
	public void addsSecurityByLinkingFacility() {
	
		SecuritySummaryAction.addSecurity(driver, element);

	}
	
	
	@Given ("^user navigates to Group Summary$")
	public void userNavigatesToGroupSummary() {
	
		NavigateToLeftPanelFieldAction.clickGroupSummary(driver, element);

	}
	
	
	@Then ("^Credit Application is present in Sanction status in Customer History$")
	public void CreditApplicationIsPresentInSanctionStatusInCustomerHistory () {
		
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		//do it one more time to refresh the page
		NavigateToLeftPanelFieldAction.clickCustomerHistory(driver, element);
		CustomerHistoryAction.verifyCreditAppStatusSanctioned(driver, element);
	}
	
	@Then ("^user is able to see saved security in security summary$")
	public void userIsAbleToSeeSavedSecurityInSecuritySummary(){
		
		NavigateToLeftPanelFieldAction.clickSecuritySummary(driver, element);
		SecuritySummaryAction.verifySecurityPresent(driver, element);
		
	}
	
	
	
}
