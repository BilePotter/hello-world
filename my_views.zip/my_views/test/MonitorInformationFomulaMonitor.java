package com.ibm.barclays.zeus.test;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.barclays.zeus.actions.AlertUserAction;
import com.ibm.barclays.zeus.actions.BackDateMIFMAction;
import com.ibm.barclays.zeus.actions.CustomerInformationAction;
import com.ibm.barclays.zeus.actions.FormulaMonitorAction;
import com.ibm.barclays.zeus.actions.GradingSummaryAndHistoryAction;
import com.ibm.barclays.zeus.actions.MonitorInformationAction;
import com.ibm.barclays.zeus.actions.NavigateToLeftPanelFieldAction;
import com.ibm.barclays.zeus.utils.DriverFactory;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MonitorInformationFomulaMonitor {
	
	public  WebDriver driver = DriverFactory.getInstance().openBrowser();
	//public  WebDriver driver;
	WebElement element = null;
	
	
	@When("^Alert Setup is configured for lead customer$")
	public void alert_Setup_is_configured_for_lead_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
		NavigateToLeftPanelFieldAction.clickAlertUserSetup(driver, element);
		
		System.out.println("Navigated to Alert User Setup Screen");
		//Thread.sleep(1000);
		if(AlertUserAction.verifyAlertSetupAlreadyExists(driver, element))
		System.out.println("Alert Setup Alerdy Exists for this Customer");
		else{
			AlertUserAction.selectSupportUser(driver, element);
			AlertUserAction.selectCreditTeam(driver, element);
			AlertUserAction.selectRCUTeam(driver, element);
			AlertUserAction.selectRCUOwner(driver, element);
			AlertUserAction.performSave(driver, element);
			System.out.println("Alert Setup is Done Successfully and Saved");
		}
	   
	}

	@When("^Monitor Information is configured for customer$")
	public void monitor_Information_is_configured_for_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   NavigateToLeftPanelFieldAction.clickMonitorInformation(driver,element);
	   MonitorInformationAction.clickAddButton(driver, element);
	   MonitorInformationAction.selectMonitorInformation(driver, element);
	   MonitorInformationAction.selectAccountType(driver, element);
	   MonitorInformationAction.linkFacilities(driver, element);
	   MonitorInformationAction.selectFrequency(driver, element);
	   MonitorInformationAction.setFirstPeriodEndDate(driver, element);
	   MonitorInformationAction.selectPeriodCovered(driver, element);
	   MonitorInformationAction.performSave(driver, element);
	}

	@When("^Formula Monitors is configured for customer$")
	public void formula_Monitors_is_configured_for_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	    NavigateToLeftPanelFieldAction.clickFormulaMonitors(driver, element);
	    FormulaMonitorAction.clickAddButton(driver,element);
	    FormulaMonitorAction.selectMonitorType(driver,element);
	    FormulaMonitorAction.selectCalculationType(driver,element);
	    FormulaMonitorAction.selectFormula(driver, element);
	    FormulaMonitorAction.linkFacilities(driver,element);
	    FormulaMonitorAction.selectFrequency(driver, element);
	    FormulaMonitorAction.setFirstPeriodEndDate(driver, element);
	    FormulaMonitorAction.selectCalculationBasis(driver, element);
	    FormulaMonitorAction.selectTargetCover(driver, element);
	    //FormulaMonitorAction.selectTypeOfCover(driver, element);
	    FormulaMonitorAction.selectResultMustBe(driver, element);
	    FormulaMonitorAction.setTimesCover(driver, element);
	    FormulaMonitorAction.performSave(driver, element);
	    
	    
	    
	}

	
	@When("^Grading Summary and History is Applied$")
	public void grading_Summary_and_History_is_Applied() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		NavigateToLeftPanelFieldAction.clickGradingSummaryAndHistory(driver, element);
	   GradingSummaryAndHistoryAction.applyGradingModel(driver,element); 
	}
	
	@When("^DRU FLAG is Yes at Customer Information Screen$")
	public void dru_FLAG_is_Yes_at_Customer_Information_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		NavigateToLeftPanelFieldAction.clickCustomerInformation(driver, element);
		CustomerInformationAction.verifyDRUFlag(driver,element);
	}

	@When("^Actual Date is Backdated for MI FM$")
	public void actual_Date_is_Backdated_for_MI_FM() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    BackDateMIFMAction.backDateMI(MonitorInformationAction.monitorInfoID, MonitorInformationAction.mIFrequency);
	    BackDateMIFMAction.backDateFM(FormulaMonitorAction.formulaMonitorID, FormulaMonitorAction.fMFrequency);
	}

	@When("^Timer is Run to Generate Alerts$")
	public void timer_is_Run_to_Generate_Alerts() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	@When("^Input Actuals are Entered for the Customer$")
	public void input_Actuals_are_Entered_for_the_Customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	

	@When("^Action is Taken on Formula Breach Alert by searching appropriate Alert from Inbox$")
	public void action_is_Taken_on_Formula_Breach_Alert_by_searching_appropriate_Alert_from_Inbox() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Action is Taken by RO from Inbox on Formula Breach Alert$")
	public void action_is_Taken_by_RO_from_Inbox_on_Formula_Breach_Alert() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	@When("^Action is Taken by Credit User on Formula Breach Alert$")
	public void action_is_Taken_by_Credit_User_on_Formula_Breach_Alert() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^M&C History should have Formula Breach Alert for Final Action Taken by RCU$")
	public void m_C_History_should_have_Formula_Breach_Alert_for_Final_Action_Taken_by_RCU() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Next Review Date should get updated to future (\\d+) days date that is equal to date populated during Credit User action$")
	public void next_Review_Date_should_get_updated_to_future_days_date_that_is_equal_to_date_populated_during_Credit_User_action(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
