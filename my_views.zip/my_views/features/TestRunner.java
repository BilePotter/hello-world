package com.ibm.barclays.zeus.features;

 
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty", "html:target/site/cucumber-pretty","json:target/cucumber.json", "junit:target/junit-cucumber.xml"},
		//features = "C:"\"\Users\G01109838\workspace\ZeusAutomation\src\com\ibm\barclays\zeus\features",
		glue= {"com.ibm.barclays.zeus.test"} , monochrome = true, /*tags = "@MIFM" */ tags = "@Security"
		)
 
public class TestRunner {

}

