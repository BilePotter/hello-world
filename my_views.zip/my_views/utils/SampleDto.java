package com.ibm.barclays.zeus.utils;


public class SampleDto {
	
	private String fieldId;
	private String fieldValue;
	private String parentKey;
	public String getFieldId() {
		return fieldId;
	}
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getParentKey() {
		return parentKey;
	}
	public void setParentKey(String parentKey) {
		this.parentKey = parentKey;
	}
	
	// private List<SampleDto> childrenItems; 
	
	
	
	

}
